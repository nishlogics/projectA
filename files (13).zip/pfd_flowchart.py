"""Chemistry flow-diagram writer.

Reuses the grid-anchored (cell-based) flow writer so text stays aligned, and adds
the mass-balance header, raw-material table and volume ledger in the 'with numbers'
mode. Operation and decision boxes come from merged bordered cells, not floating
shapes.
"""

from __future__ import annotations

import io

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from pfd_scaleup import StageCalc
from pfd_pipeline import is_decision
from flow_extractor import FlowStep
import flow_writer as fw


def _steps_to_flowsteps(stage: StageCalc) -> list[FlowStep]:
    out = []
    for s in stage.steps:
        fs = FlowStep(number=s.number, text=s.full_text)
        if is_decision(s):
            fs.is_decision = True
            fs.text = s.full_text
            fs.yes_text = "Yes"
            fs.no_text = "No"
        # attach material/qty as a suffix line inside the box
        if getattr(s, "materials", None):
            q = ", ".join(str(round(v, 2)) for v in s.quantities if v)
            add = ", ".join(s.materials) + (f" ({q})" if q else "")
            if not fs.is_decision:
                fs.text = f"{fs.text}\n[{add}]"
        out.append(fs)
    return out


def build_diagram(stages: list[StageCalc]) -> bytes:
    """Flow diagram only (one sheet per stage)."""
    from openpyxl import Workbook
    # build each stage into its own file then merge sheets
    wb = Workbook(); wb.remove(wb.active)
    for i, stage in enumerate(stages, 1):
        title = (stage.name or f"Stage {i}")
        data = fw.build(_steps_to_flowsteps(stage),
                        title=f"PROCESS FLOW DIAGRAM  -  {stage.project}" if stage.project
                        else "PROCESS FLOW DIAGRAM")
        src = load_workbook(io.BytesIO(data))
        _copy_sheet(src.active, wb, title[:31])
    buf = io.BytesIO(); wb.save(buf); return buf.getvalue()


def build_with_numbers(stages: list[StageCalc]) -> bytes:
    """Flow diagram + mass balance header + material table + volume ledger."""
    from openpyxl import Workbook
    wb = Workbook(); wb.remove(wb.active)
    for i, stage in enumerate(stages, 1):
        ws = wb.create_sheet(title=(stage.name or f"Stage {i}")[:31])
        _write_numbers_sheet(ws, stage)
    buf = io.BytesIO(); wb.save(buf); return buf.getvalue()


# ---------------------------------------------------------------------------
_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
_LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)
_GREEN = PatternFill("solid", fgColor="92D050")
_HDR = PatternFill("solid", fgColor="D9E1F2")
_THIN = Side(style="thin", color="9DB2CE")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


def _fmt(v, n=2):
    if v is None:
        return ""
    if isinstance(v, (int, float)):
        return f"{v:g}" if float(v) == int(v) else f"{round(v, n):g}"
    return str(v)


def _copy_sheet(src_ws, dst_wb, title):
    dst = dst_wb.create_sheet(title=title)
    dst.sheet_view.showGridLines = False
    for col, dim in src_ws.column_dimensions.items():
        dst.column_dimensions[col].width = dim.width
    for row, dim in src_ws.row_dimensions.items():
        dst.row_dimensions[row].height = dim.height
    for mc in src_ws.merged_cells.ranges:
        dst.merge_cells(str(mc))
    from copy import copy
    for row in src_ws.iter_rows():
        for cell in row:
            d = dst.cell(row=cell.row, column=cell.column, value=cell.value)
            if cell.has_style:
                d.font = copy(cell.font); d.fill = copy(cell.fill)
                d.border = copy(cell.border); d.alignment = copy(cell.alignment)
    return dst


def _write_numbers_sheet(ws, stage: StageCalc):
    ws.sheet_view.showGridLines = False
    for col, w in {"A": 3, "B": 16, "C": 16, "D": 16, "E": 16, "F": 4,
                   "G": 14, "H": 14, "I": 14, "J": 14}.items():
        ws.column_dimensions[col].width = w

    lbl = Font(name="Calibri", bold=True, size=10)
    val = Font(name="Calibri", size=10)

    ws.merge_cells("B1:J1")
    t = ws["B1"]; t.value = ("PROCESS FLOW DIAGRAM  -  " + stage.project) if stage.project else "PROCESS FLOW DIAGRAM"
    t.font = Font(name="Calibri", bold=True, size=15, color="FFFFFF")
    t.fill = PatternFill("solid", fgColor="1F4E78"); t.alignment = _CENTER
    ws.row_dimensions[1].height = 30

    def put(cell, text, f, fill=None):
        ws[cell] = text; ws[cell].font = f
        if fill: ws[cell].fill = fill

    put("B3", "Batch size", lbl); ws["C3"] = _fmt(stage.plant_batch_kg); ws["C3"].font = val; put("D3", "Kg", val)
    put("G3", "Output", lbl); ws["H3"] = _fmt(stage.output_kg); ws["H3"].font = val; put("I3", "Kg", val)
    put("B4", "Input MW", lbl); ws["C4"] = _fmt(stage.input_mw); ws["C4"].font = val
    put("G4", "Product MW", lbl); ws["H4"] = _fmt(stage.product_mw); ws["H4"].font = val
    moles = getattr(stage, "moles_report", None) or stage.input_moles
    put("B5", "Moles", lbl); ws["C5"] = _fmt(moles, 4); ws["C5"].font = val
    put("G5", "Yield", lbl); ws["H5"] = _fmt(stage.yield_frac); ws["H5"].font = val

    # raw-material table
    tr = 7
    for c, h in enumerate(["S.No", "Raw material", "Qty", "Unit", "MW",
                           "Mole ratio", "Plant Kg", "Plant L"], 2):
        cell = ws.cell(row=tr, column=c, value=h)
        cell.font = lbl; cell.fill = _GREEN; cell.border = _BORDER; cell.alignment = _CENTER
    tr += 1
    for m in stage.materials:
        qty = m.lab_qty_g if m.lab_qty_g else m.lab_vol_ml
        unit = "g" if m.lab_qty_g else ("mL" if m.lab_vol_ml else "")
        vals = [m.sr_no, m.name, _fmt(qty), unit, _fmt(m.mw),
                m.remarks, _fmt(m.plant_kg), _fmt(m.plant_l)]
        for c, v in enumerate(vals, 2):
            cell = ws.cell(row=tr, column=c, value=v)
            cell.border = _BORDER; cell.font = val
            cell.alignment = _LEFT if c == 3 else _CENTER
        tr += 1

    # flow diagram below, built as grid boxes with the volume ledger on the right
    _draw_flow_with_ledger(ws, stage, start_row=tr + 2)


def _box(ws, r0, c0, r1, c1, text, fill, edge, txtcolor, bold=True, size=11):
    ws.merge_cells(start_row=r0, start_column=c0, end_row=r1, end_column=c1)
    fillp = PatternFill("solid", fgColor=fill)
    border = Border(*(Side(style="medium", color=edge),) * 4) if False else Border(
        left=Side(style="medium", color=edge), right=Side(style="medium", color=edge),
        top=Side(style="medium", color=edge), bottom=Side(style="medium", color=edge))
    for r in range(r0, r1 + 1):
        for c in range(c0, c1 + 1):
            cell = ws.cell(row=r, column=c); cell.fill = fillp; cell.border = border
    top = ws.cell(row=r0, column=c0, value=text)
    top.font = Font(name="Calibri", bold=bold, size=size, color=txtcolor)
    top.alignment = _CENTER


def _draw_flow_with_ledger(ws, stage, start_row):
    r = start_row
    MAIN0, MAIN1, MID = 2, 5, 3
    LED0, LED1 = 7, 9

    def rows(n):
        nonlocal r
        for rr in range(r, r + n): ws.row_dimensions[rr].height = 20
        top = r; r += n; return top

    top = rows(2)
    _box(ws, top, MAIN0, top + 1, MAIN1, "START", "C6E0B4", "548235", "1F3864")
    a = ws.cell(row=r, column=MID, value="\u2193"); a.font = Font(size=16, bold=True, color="2E5496"); a.alignment = _CENTER
    r += 1

    steps = stage.steps
    for idx, s in enumerate(steps):
        last = idx == len(steps) - 1
        top = rows(3)
        dec = is_decision(s)
        fill, edge, txt = ("2E75B6", "1F4E78", "FFFFFF") if dec else ("EAF1FB", "2E5496", "1F3864")
        _box(ws, top, MAIN0, top + 2, MAIN1, s.full_text, fill, edge, txt)

        # material label (left, col A won't fit; use a note above ledger) -> put on ledger side
        if s.min_vol is not None or s.max_vol is not None:
            _box(ws, top, LED0, top + 2, LED1,
                 f"{_fmt(s.min_vol)} \u2013 {_fmt(s.max_vol)} L", "FFF2CC", "BF9000", "7F6000", bold=False, size=10)
        if getattr(s, "materials", None):
            q = ", ".join(_fmt(v) for v in s.quantities if v)
            lab = ws.cell(row=top + 1, column=6, value="")  # spacer
        if not last:
            a = ws.cell(row=r, column=MID, value="\u2193"); a.font = Font(size=16, bold=True, color="2E5496"); a.alignment = _CENTER
            r += 1

    a = ws.cell(row=r, column=MID, value="\u2193"); a.font = Font(size=16, bold=True, color="2E5496"); a.alignment = _CENTER
    r += 1
    top = rows(2)
    _box(ws, top, MAIN0, top + 1, MAIN1, "END", "C6E0B4", "548235", "1F3864")
