"""AI-driven flowsheet prototype.

Reads any document (Word / PDF / Excel / text), uses Claude to understand the
process — steps, decisions, materials, unit operations and the mass balance —
then renders a professional flow diagram:

  * operation boxes  : merged, bordered cells (grid-anchored, text never drifts)
  * decision boxes   : same, styled distinctly, with Yes / No branches
  * connectors       : thin vertical lines with triangular arrowheads, drawn as
                       DrawingML exactly like a hand-made engineering flowsheet
  * mass balance     : computed by the model and shown alongside the diagram

Falls back to a built-in parser when no API key is supplied.
"""

from __future__ import annotations

import io
import json
import re
import zipfile
from dataclasses import dataclass, field
from typing import Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

EMU = 9525  # EMU per pixel


# ---------------------------------------------------------------------------
# data model
# ---------------------------------------------------------------------------
@dataclass
class Stream:
    name: str
    qty: Optional[float] = None
    unit: str = ""
    mw: Optional[float] = None
    density: Optional[float] = None
    role: str = ""            # reactant / solvent / reagent / product / waste
    # computed by compute()
    plant_kg: Optional[float] = None
    plant_l: Optional[float] = None
    moles: Optional[float] = None
    ww: Optional[float] = None
    vw: Optional[float] = None


@dataclass
class Node:
    idx: int
    text: str
    kind: str = "operation"   # operation | decision | terminator
    yes: str = ""
    no: str = ""
    unit_op: str = ""
    inputs: list = field(default_factory=list)     # stream names charged here
    vol_in: Optional[float] = None
    vol_out: Optional[float] = None


@dataclass
class Sheet:
    title: str
    stage_name: str = ""
    nodes: list = field(default_factory=list)
    streams: list = field(default_factory=list)
    basis: str = ""
    balance: dict = field(default_factory=dict)   # {'input_kg':..,'output_kg':..,'yield':..}
    notes: str = ""


# ---------------------------------------------------------------------------
# AI extraction
# ---------------------------------------------------------------------------
_SYSTEM = """You are a chemical process engineer. From the supplied document text,
identify the process structure and the chemistry needed for a mass balance.
Reply with JSON only. Do not compute plant quantities, moles, volumes, W/w, V/W,
or the ledger — those are computed downstream. Your only numeric duty is to
report molecular weights, densities and the yield.

JSON schema:
{
 "title": "<process / product name>",
 "basis": "<basis, e.g. '100 g L-Tyrosine'>",
 "streams": [
   {"name":"",
    "qty":<lab-scale qty, number>,
    "unit":"g|mL",
    "mw":<number, supply from chemistry knowledge if the doc omits it>,
    "density":<number, g/mL>,
    "role":"reactant|reagent|solvent|catalyst|product|waste"}
 ],
 "nodes": [
   {"idx":1,
    "text":"<short imperative step, <=90 chars>",
    "kind":"operation|decision",
    "yes":"<if decision: what happens on pass>",
    "no":"<if decision: on fail>",
    "unit_op":"Charging|Reaction|Work-up|Distillation|Filtration|Crystallization|Drying|Analysis",
    "inputs":["<exact stream names charged in this step>"]}
 ],
 "balance": {"input_mw": <number, MW of the starting material>,
             "product_mw": <number, MW of the final product>,
             "yield": <fraction 0-1, e.g. 0.80 for 80%>}
}

Critical rules:
- Fill mw AND density for EVERY stream. If the report doesn't state them,
  supply the correct value from your chemistry knowledge:
  water 18.02/1.00, HCl (conc 35%) 36.46/1.18, NaOH 40.0/2.13,
  NaOH solution (25%) 40/1.28, toluene 92.14/0.87, ethanol 46.07/0.79,
  methanol 32.04/0.79, DCM 84.93/1.33, acetone 58.08/0.79,
  chloroacetyl chloride 112.94/1.42, ammonia (28% aq) 17.03/0.90.
- input_mw = MW of the starting material used as the basis.
- product_mw = MW of the final isolated product (usually a different compound).
- inputs must use the EXACT same names as in streams[].name so the ledger links.
- Preserve process order. Keep node text short and imperative.
Return only the JSON object."""


def extract_with_ai(text: str, api_key: str, model: str = "llama-3.3-70b-versatile") -> Sheet:
    from groq import Groq
    client = Groq(api_key=api_key)
    resp = client.chat.completions.create(
        model=model,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": f"Document:\n\n{text[:60000]}\n\nJSON:"},
        ],
    )
    raw = resp.choices[0].message.content
    return _to_sheet(_loads(raw))


def _loads(raw: str) -> dict:
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?", "", raw).strip()
    raw = re.sub(r"```$", "", raw).strip()
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    return json.loads(m.group(0) if m else raw)


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Deterministic calculations - matches the reference CTGR3 template exactly.
# The AI only identifies steps, decisions and material charges; every number
# below is computed here so nothing depends on the model getting math right.
# ---------------------------------------------------------------------------
def compute(sheet: "Sheet", batch_size_kg: float, sm_lab_g: float = 100.0) -> None:
    """Fill in plant quantities, moles, W/w, V/W, output and the running volume
    ledger. Mutates the Sheet in place.

        Scale-up ratio     = batch_size_kg * 1000 / sm_lab_g   (e.g. 41*1000/100 = 410)
        Plant qty (Kg)     = lab_qty(g)  * ratio / 1000        (solid stream)
        Plant vol (L)      = lab_vol(mL) * ratio / 1000        (liquid stream)
        Moles              = plant_kg / MW                     (in kgmol)
        W/w                = plant_kg / batch_size_kg
        V/W                = plant_L  / batch_size_kg
        Solid-as-solution  = plant_kg / density               (used in the ledger)
        Output_kg          = batch_size / input_MW * yield * product_MW

    The volume ledger walks the process step by step: within an equipment block
    Min = previous Max and Max = Min + Σ(volumes charged this step); an unload /
    transfer / distill / filter operation ends the block, and the next step
    restarts from 0. Occupancy = ledger volume / equipment capacity.
    """
    bal = sheet.balance or {}
    imw = bal.get("input_mw") or 1.0
    pmw = bal.get("product_mw") or imw
    yld = bal.get("yield") or 0.8

    ratio = batch_size_kg * 1000.0 / sm_lab_g if sm_lab_g else 1.0
    output_kg = batch_size_kg / imw * yld * pmw if imw else 0.0

    sheet.balance = {
        "input_kg": batch_size_kg,
        "input_mw": imw,
        "product_mw": pmw,
        "yield": yld,
        "scale_up_ratio": ratio,
        "output_kg": output_kg,
        "input_moles": batch_size_kg / imw if imw else None,
        "output_moles": output_kg / pmw if pmw else None,
    }

    # ---- stream table: plant quantities, moles, W/w, V/W ---------------------
    for s in sheet.streams:
        is_solid = (s.unit or "").lower().startswith("g")
        if is_solid and s.qty is not None:
            s.plant_kg = s.qty * ratio / 1000.0
            s.plant_l = (s.plant_kg / s.density) if s.density else None
        elif s.qty is not None:                       # liquid mL -> L
            s.plant_l = s.qty * ratio / 1000.0
            s.plant_kg = (s.plant_l * s.density) if s.density else None
        else:
            s.plant_kg = s.plant_l = None
        # Moles is computed at LAB scale: lab qty (g) / MW -- e.g. 100 g L-Tyrosine
        # / 181.19 = 0.55. This is the same for solids and liquids-with-density,
        # since the report's Moles column always uses the gram quantity.
        lab_g = s.qty if is_solid else ((s.qty * s.density) if (s.qty and s.density) else None)
        s.moles = (lab_g / s.mw) if (lab_g and s.mw) else None
        s.ww = (s.plant_kg / batch_size_kg) if s.plant_kg else None
        s.vw = (s.plant_l / batch_size_kg) if s.plant_l else None

    # ---- volume ledger walking the process -----------------------------------
    # Matches the reference sheet exactly:
    #   - a step that charges material(s): Min = running total, Max = Min + qty
    #     charged in that step; running total updates to Max.
    #   - a step with nothing charged (cool/stir/maintain/decision/the separation
    #     step itself): ledger is BLANK, not a repeated number.
    #   - unload / transfer / distill / filter / separate steps end the current
    #     equipment block: the running total resets to 0 for whatever charges
    #     next (which may be into a different equipment ID, e.g. after a layer
    #     split the aqueous layer is charged fresh into the next reactor).
    by_name = {s.name.lower(): s for s in sheet.streams}
    running = 0.0
    for n in sheet.nodes:
        if n.kind not in ("operation", "decision"):
            continue
        low = n.text.lower()
        block_end = any(k in low for k in
                        ("unload", "transfer", "distill", "filter", "separate"))
        added = 0.0
        for m in n.inputs:
            s = by_name.get(m.lower())
            if s is not None and s.plant_l:
                added += s.plant_l
        if added > 0:
            n.vol_in = running
            n.vol_out = running + added
            running = n.vol_out
        else:
            n.vol_in = None
            n.vol_out = None
        if block_end:
            running = 0.0


def _to_sheet(d: dict) -> Sheet:
    sh = Sheet(title=d.get("title", "Process"), basis=d.get("basis", ""))
    for s in d.get("streams", []):
        sh.streams.append(Stream(
            name=s.get("name", ""), qty=_num(s.get("qty")), unit=s.get("unit", ""),
            mw=_num(s.get("mw")), density=_num(s.get("density")), role=s.get("role", "")))
    for i, n in enumerate(d.get("nodes", []), 1):
        sh.nodes.append(Node(
            idx=n.get("idx", i), text=n.get("text", "").strip(),
            kind=n.get("kind", "operation"), yes=n.get("yes", ""), no=n.get("no", ""),
            unit_op=n.get("unit_op", ""), inputs=list(n.get("inputs", []))))
    b = d.get("balance", {}) or {}
    sh.balance = {k: _num(b.get(k)) for k in
                  ("input_kg", "output_kg", "yield", "input_mw", "product_mw")}
    sh.notes = b.get("explanation", "")
    return sh


# ---------------------------------------------------------------------------
# offline fallback
# ---------------------------------------------------------------------------
def extract_fallback(text: str) -> Sheet:
    from flow_extractor import _lines_to_steps
    steps = _lines_to_steps(text.splitlines())
    sh = Sheet(title="Process")
    for s in steps:
        sh.nodes.append(Node(idx=s.number, text=s.text,
                             kind="decision" if s.is_decision else "operation",
                             yes=s.yes_text, no=s.no_text))
    return sh


def read_text(file, filename: str) -> str:
    name = (filename or "").lower()
    if name.endswith(".docx"):
        from docx import Document
        doc = Document(file)
        parts = [p.text for p in doc.paragraphs]
        for t in doc.tables:
            for row in t.rows:
                parts.append(" | ".join(c.text for c in row.cells))
        return "\n".join(parts)
    if name.endswith((".xlsx", ".xls", ".xlsm", ".csv")):
        import pandas as pd
        df = (pd.read_csv(file, header=None, dtype=str) if name.endswith(".csv")
              else pd.read_excel(file, header=None, dtype=str))
        return "\n".join(" | ".join(str(c) for c in row if str(c) != "nan")
                         for _, row in df.iterrows())
    import pdfplumber
    with pdfplumber.open(file) as pdf:
        return "\n".join((p.extract_text() or "") for p in pdf.pages)


# ---------------------------------------------------------------------------
# multi-stage splitting
# ---------------------------------------------------------------------------
_STAGE_HEADING = re.compile(
    r"(?i)(CGTR|CTGR)\s*([0-9]+)\b.*(draft process|process description|scheme|synthetic)")
_STAGE_TAG = re.compile(r"(?i)(CGTR|CTGR)\s*([0-9]+)\b")


def split_stages(text: str) -> list[tuple[str, str]]:
    """Split a report into (stage_name, stage_text) chunks.

    Many reports repeat a banner line on every page listing ALL stages
    ('CGTR1, CGTR2 and CGTR3 Draft process'); that banner must NOT be treated
    as a stage heading or every page gets misassigned to the last stage named
    in it. A real heading line names exactly one stage and isn't a banner.
    """
    lines = text.splitlines()
    idxs = []
    for i, ln in enumerate(lines):
        low = ln.strip().lower()
        if "cgtr" not in low and "ctgr" not in low:
            continue
        if " and " in low or (low.count("cgtr") + low.count("ctgr")) > 1:
            continue  # banner line naming multiple stages -> skip
        m = _STAGE_HEADING.search(ln)
        if m:
            idxs.append((i, f"Stage{m.group(2)}"))

    if not idxs:
        return [("Stage1", text)]

    seen = {}
    for pos, name in idxs:
        if name not in seen:
            seen[name] = pos
    ordered = sorted(seen.items(), key=lambda kv: kv[1])

    chunks = []
    for k, (name, start) in enumerate(ordered):
        end = ordered[k + 1][1] if k + 1 < len(ordered) else len(lines)
        chunks.append((name, "\n".join(lines[start:end])))
    return chunks


def extract_all_stages(text: str, api_key: Optional[str] = None) -> list[Sheet]:
    """Split the document into stages and extract each one separately, so a
    step or material in stage 2/3 can never be swallowed by stage 1."""
    sheets = []
    for name, chunk in split_stages(text):
        sh = None
        if api_key:
            try:
                sh = extract_with_ai(chunk, api_key)
            except Exception:
                sh = None
        if sh is None:
            sh = extract_fallback(chunk)
        if not sh.title or sh.title == "Process":
            sh.title = name
        sh.stage_name = name
        sheets.append(sh)
    return sheets


# ---------------------------------------------------------------------------
# rendering — cell boxes + hand-drawn style line arrows
# ---------------------------------------------------------------------------
OP_FILL, OP_EDGE, OP_TEXT = "FFFFFF", "1F3864", "1F3864"
DEC_FILL, DEC_EDGE, DEC_TEXT = "DEEBF7", "1F4E78", "1F3864"
TERM_FILL, TERM_EDGE = "E2EFDA", "375623"
NO_FILL, NO_EDGE = "FCE4E4", "A61C1C"

_C = Alignment(horizontal="center", vertical="center", wrap_text=True)
_L = Alignment(horizontal="left", vertical="center", wrap_text=True)


def _border(color, weight="thin"):
    s = Side(style=weight, color=color)
    return Border(left=s, right=s, top=s, bottom=s)


def _box(ws, r0, c0, r1, c1, text, fill, edge, txt, bold=False, size=10):
    ws.merge_cells(start_row=r0, start_column=c0, end_row=r1, end_column=c1)
    f = PatternFill("solid", fgColor=fill)
    b = _border(edge)
    for r in range(r0, r1 + 1):
        for c in range(c0, c1 + 1):
            cell = ws.cell(row=r, column=c)
            cell.fill = f
            cell.border = b
    t = ws.cell(row=r0, column=c0, value=text)
    t.font = Font(name="Calibri", size=size, bold=bold, color=txt)
    t.alignment = _C


def _arrow_sp(sid, x, y, height):
    """A thin vertical line with a triangular arrowhead — the classic
    engineering-flowsheet connector."""
    ox, oy, cy = int(x * EMU), int(y * EMU), int(height * EMU)
    return (f'<xdr:sp macro="" textlink=""><xdr:nvSpPr>'
            f'<xdr:cNvPr id="{sid}" name="Line {sid}"/>'
            f'<xdr:cNvSpPr><a:spLocks noChangeShapeType="1"/></xdr:cNvSpPr></xdr:nvSpPr>'
            f'<xdr:spPr bwMode="auto"><a:xfrm><a:off x="{ox}" y="{oy}"/>'
            f'<a:ext cx="0" cy="{cy}"/></a:xfrm>'
            f'<a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:noFill/>'
            f'<a:ln w="9525"><a:solidFill><a:srgbClr val="1F3864"/></a:solidFill>'
            f'<a:round/><a:headEnd/><a:tailEnd type="triangle" w="med" len="med"/></a:ln>'
            f'</xdr:spPr></xdr:sp>')


def _hline_sp(sid, x, y, width):
    ox, oy, cx = int(x * EMU), int(y * EMU), int(width * EMU)
    return (f'<xdr:sp macro="" textlink=""><xdr:nvSpPr>'
            f'<xdr:cNvPr id="{sid}" name="HLine {sid}"/>'
            f'<xdr:cNvSpPr><a:spLocks noChangeShapeType="1"/></xdr:cNvSpPr></xdr:nvSpPr>'
            f'<xdr:spPr bwMode="auto"><a:xfrm><a:off x="{ox}" y="{oy}"/>'
            f'<a:ext cx="{cx}" cy="0"/></a:xfrm>'
            f'<a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:noFill/>'
            f'<a:ln w="9525"><a:solidFill><a:srgbClr val="A61C1C"/></a:solidFill>'
            f'<a:round/><a:headEnd/><a:tailEnd type="triangle" w="med" len="med"/></a:ln>'
            f'</xdr:spPr></xdr:sp>')


def render(sheet: Sheet) -> bytes:
    """Render a single stage into its own workbook."""
    wb = Workbook()
    ws = wb.active
    ws.title = (sheet.stage_name or "Flowsheet")[:31]
    shapes = _render_sheet(ws, sheet)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return _inject_multi(buf.getvalue(), {ws.title: shapes})


def render_all(sheets: list[Sheet]) -> bytes:
    """Render every stage into one workbook, one sheet per stage — so a
    3-stage report always produces 3 sheets, never silently drops any."""
    wb = Workbook()
    wb.remove(wb.active)
    all_shapes = {}
    for sh in sheets:
        title = (sh.stage_name or sh.title or "Stage")[:31]
        base, n = title, 2
        while title in wb.sheetnames:
            title = f"{base[:28]}_{n}"; n += 1
        ws = wb.create_sheet(title=title)
        all_shapes[title] = _render_sheet(ws, sh)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return _inject_multi(buf.getvalue(), all_shapes)


def _render_sheet(ws, sheet: Sheet) -> list:
    ws.sheet_view.showGridLines = False

    for col, w in {"A": 2, "B": 18, "C": 18, "D": 18, "E": 18,
                   "F": 3, "G": 20, "H": 20, "I": 14, "J": 14}.items():
        ws.column_dimensions[col].width = w

    # title
    ws.merge_cells("B1:H1")
    t = ws["B1"]
    t.value = sheet.title.upper()
    t.font = Font(name="Calibri", bold=True, size=14, color="1F3864")
    t.alignment = _C
    ws.row_dimensions[1].height = 24
    if sheet.basis:
        ws.merge_cells("B2:H2")
        b = ws["B2"]; b.value = f"Basis: {sheet.basis}"
        b.font = Font(name="Calibri", italic=True, size=9, color="595959")
        b.alignment = _C

    # mass balance strip
    bal = sheet.balance or {}
    if any(v for v in bal.values() if v is not None):
        ws.merge_cells("B3:H3")
        parts = []
        if bal.get("input_kg"): parts.append(f"Batch {bal['input_kg']:g} kg")
        if bal.get("input_mw"): parts.append(f"MW in {bal['input_mw']:g}")
        if bal.get("yield"): parts.append(f"Yield {bal['yield']*100:.1f}%")
        if bal.get("product_mw"): parts.append(f"MW out {bal['product_mw']:g}")
        if bal.get("output_kg"): parts.append(f"Output {bal['output_kg']:.2f} kg")
        if bal.get("scale_up_ratio"): parts.append(f"Ratio {bal['scale_up_ratio']:g}")
        m = ws["B3"]; m.value = "   •   ".join(parts)
        m.font = Font(name="Calibri", bold=True, size=10, color="375623")
        m.alignment = _C

    # geometry: each box 3 rows tall, 1 spacer row for the arrow
    ROW_H = 18
    BOX_ROWS, GAP_ROWS = 3, 1
    MAIN0, MAIN1 = 2, 5      # columns B..E
    NO0, NO1 = 7, 8          # columns G..H

    r = 5
    shapes = []
    sid = 2

    def px_y(row):            # top of a row, in px, given uniform row heights
        return 20 + (row - 1) * ROW_H

    def col_center_px(c0, c1):
        # approximate: column width units ~7px each
        widths = [2, 18, 18, 18, 18, 3, 20, 20, 14, 14]
        x = 10
        for i in range(0, c0 - 1):
            x += widths[i] * 7
        span = sum(widths[i] for i in range(c0 - 1, c1)) * 7
        return int(x + span / 2)

    def rows(n):
        nonlocal r
        for rr in range(r, r + n):
            ws.row_dimensions[rr].height = ROW_H
        top = r
        r += n
        return top

    cx_main = col_center_px(MAIN0, MAIN1)

    # START
    top = rows(2)
    _box(ws, top, MAIN0, top + 1, MAIN1, "START", TERM_FILL, TERM_EDGE, "375623", bold=True)
    gap_top = rows(GAP_ROWS)
    shapes.append(_arrow_sp(sid, cx_main, px_y(gap_top), ROW_H)); sid += 1

    for i, n in enumerate(sheet.nodes):
        last = i == len(sheet.nodes) - 1
        top = rows(BOX_ROWS)
        if n.kind == "decision":
            _box(ws, top, MAIN0, top + BOX_ROWS - 1, MAIN1, n.text,
                 DEC_FILL, DEC_EDGE, DEC_TEXT, bold=True)
            # No branch box + horizontal arrow
            no_txt = n.no or "Rework / stop"
            _box(ws, top, NO0, top + BOX_ROWS - 1, NO1, no_txt, NO_FILL, NO_EDGE, NO_EDGE, size=9)
            y_mid = px_y(top) + (BOX_ROWS * ROW_H) / 2
            x_from = col_center_px(MAIN1, MAIN1) + 60
            shapes.append(_hline_sp(sid, x_from, y_mid, 55)); sid += 1
        else:
            label = n.text
            if n.inputs:
                label += "\n[" + ", ".join(n.inputs) + "]"
            _box(ws, top, MAIN0, top + BOX_ROWS - 1, MAIN1, label, OP_FILL, OP_EDGE, OP_TEXT)
        if n.unit_op:
            u = ws.cell(row=top, column=10, value=n.unit_op)
            u.font = Font(name="Calibri", size=8, italic=True, color="808080")
            u.alignment = _L
        # Min / Max volume ledger next to the step (CTGR3-style)
        if n.vol_in is not None or n.vol_out is not None:
            def _fv(v):
                if v is None: return ""
                return f"{v:g}" if float(v).is_integer() else f"{round(v,1):g}"
            mnc = ws.cell(row=top + 1, column=11, value=_fv(n.vol_in))
            mxc = ws.cell(row=top + 1, column=12, value=_fv(n.vol_out))
            for c in (mnc, mxc):
                c.font = Font(name="Calibri", bold=True, size=9, color="1F3864")
                c.alignment = _C
                c.border = _border("1F3864")
        if not last:
            gap_top = rows(GAP_ROWS)
            shapes.append(_arrow_sp(sid, cx_main, px_y(gap_top), ROW_H)); sid += 1
            if n.kind == "decision":
                y = ws.cell(row=gap_top, column=5, value="Yes")
                y.font = Font(name="Calibri", size=8, bold=True, color="375623")
                y.alignment = _C

    gap_top = rows(GAP_ROWS)
    shapes.append(_arrow_sp(sid, cx_main, px_y(gap_top), ROW_H)); sid += 1
    top = rows(2)
    _box(ws, top, MAIN0, top + 1, MAIN1, "END", TERM_FILL, TERM_EDGE, "375623", bold=True)

    # stream table (CTGR3 columns: Lab qty | Plant qty | MW | Moles | W/w | V/W | Density | Remarks)
    if sheet.streams:
        r += 2
        # widen the sheet for the extra columns
        for col, w in {"I": 11, "J": 11, "K": 11, "L": 11, "M": 11, "N": 11}.items():
            ws.column_dimensions[col].width = w
        hdr = ["S.No", "Raw material", "Lab Qty", "Unit",
               "Plant Kg", "Plant L", "MW", "Moles",
               "W/w", "V/W", "Density", "Role"]
        for c, h in enumerate(hdr, 2):
            cell = ws.cell(row=r, column=c, value=h)
            cell.font = Font(name="Calibri", bold=True, size=9, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F3864")
            cell.border = _border("1F3864"); cell.alignment = _C
        r += 1

        def _fmt(v, n=2):
            if v is None:
                return ""
            if isinstance(v, (int, float)):
                return f"{v:g}" if float(v).is_integer() else f"{round(v, n):g}"
            return str(v)

        for i, s in enumerate(sheet.streams, 1):
            vals = [i, s.name, _fmt(s.qty), s.unit,
                    _fmt(s.plant_kg), _fmt(s.plant_l),
                    _fmt(s.mw), _fmt(s.moles, 4),
                    _fmt(s.ww), _fmt(s.vw),
                    _fmt(s.density), s.role]
            for c, v in enumerate(vals, 2):
                cell = ws.cell(row=r, column=c, value=v)
                cell.font = Font(name="Calibri", size=9)
                cell.border = _border("BFBFBF")
                cell.alignment = _L if c == 3 else _C
            r += 1

    if sheet.notes:
        r += 1
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=8)
        nn = ws.cell(row=r, column=2, value="Mass balance: " + sheet.notes)
        nn.font = Font(name="Calibri", italic=True, size=9, color="595959")
        nn.alignment = _L

    return shapes


def _inject_multi(xlsx_bytes: bytes, shapes_by_sheet: dict) -> bytes:
    """Inject DrawingML shapes into multiple worksheets of one workbook."""
    zin = zipfile.ZipFile(io.BytesIO(xlsx_bytes))
    # map sheet title -> sheetN.xml via workbook.xml / workbook.xml.rels
    wb_xml = zin.read("xl/workbook.xml").decode()
    rels_xml = zin.read("xl/_rels/workbook.xml.rels").decode()
    sheet_entries = re.findall(r'<sheet\b[^>]*\bname="([^"]+)"[^>]*\br:id="(rId\d+)"', wb_xml)
    rid_to_target = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="([^"]+)"', rels_xml))
    if not rid_to_target:
        rid_to_target = dict(re.findall(r'Target="([^"]+)"[^>]*Id="(rId\d+)"', rels_xml))
        rid_to_target = {v: k for k, v in rid_to_target.items()}

    title_to_file = {}
    for name, rid in sheet_entries:
        target = rid_to_target.get(rid, "")
        if not target:
            continue
        target = target.lstrip("/")
        if not target.startswith("xl/"):
            target = "xl/" + target
        title_to_file[name] = target

    drawings = {}
    for idx, (title, shapes) in enumerate(shapes_by_sheet.items(), 1):
        if not shapes:
            continue
        sheet_file = title_to_file.get(title)
        if not sheet_file:
            continue
        dxml = _drawing_xml(shapes)
        drawings[sheet_file] = (f"xl/drawings/drawing{idx}.xml", dxml, idx)

    out = io.BytesIO()
    zout = zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED)
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == "[Content_Types].xml":
            txt = data.decode()
            if drawings and "drawing+xml" not in txt:
                overrides = "".join(
                    f'<Override PartName="/{d[0]}" '
                    'ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>'
                    for d in drawings.values())
                txt = txt.replace("</Types>", overrides + "</Types>")
            zout.writestr(item, txt.encode()); continue
        if item.filename in drawings:
            dpath, dxml, dnum = drawings[item.filename]
            txt = data.decode()
            if "xmlns:r=" not in txt:
                txt = txt.replace(
                    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"',
                    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"', 1)
            if "<drawing " not in txt:
                txt = txt.replace("</worksheet>", f'<drawing r:id="rIdD{dnum}"/></worksheet>')
            zout.writestr(item, txt.encode())
            base = item.filename.split("/")[-1]
            zout.writestr(f"xl/worksheets/_rels/{base}.rels",
                          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                          f'<Relationship Id="rIdD{dnum}" '
                          'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" '
                          f'Target="../drawings/drawing{dnum}.xml"/></Relationships>')
            zout.writestr(dpath, dxml); continue
        zout.writestr(item, data)
    zout.close()
    return out.getvalue()


def _drawing_xml(shapes: list) -> str:
    dxml = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" '
            'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">')
    for sp in shapes:
        m = re.search(r'<a:off x="(\d+)" y="(\d+)"/><a:ext cx="(\d+)" cy="(\d+)"/>', sp)
        ox, oy, cx, cy = (m.group(1), m.group(2), m.group(3), m.group(4)) if m else ("0", "0", "0", "0")
        acx, acy = max(int(cx), 1), max(int(cy), 1)
        dxml += (f'<xdr:absoluteAnchor><xdr:pos x="{ox}" y="{oy}"/>'
                 f'<xdr:ext cx="{acx}" cy="{acy}"/>'
                 f'{sp}<xdr:clientData/></xdr:absoluteAnchor>')
    dxml += "</xdr:wsDr>"
    return dxml


# ---------------------------------------------------------------------------
# Mermaid export
# ---------------------------------------------------------------------------
def to_mermaid(sheet: "Sheet") -> str:
    """Render a Sheet as a Mermaid flowchart (top-down), with decision diamonds
    and Yes/No branches."""
    lines = ["flowchart TD"]
    lines.append(f'    START(["START"])')
    prev = "START"

    def esc(t: str) -> str:
        return (t or "").replace('"', "'").replace("\n", " ")[:90]

    for n in sheet.nodes:
        nid = f"N{n.idx}"
        if n.kind == "decision":
            label = esc(n.text)
            lines.append(f'    {nid}{{"{label}"}}')
            lines.append(f"    {prev} --> {nid}")
            yes_id = f"{nid}_yes"
            no_id = f"{nid}_no"
            if n.yes:
                lines.append(f'    {yes_id}["{esc(n.yes)}"]')
                lines.append(f"    {nid} -->|Yes| {yes_id}")
                prev = yes_id
            else:
                prev = nid
            if n.no:
                lines.append(f'    {no_id}["{esc(n.no)}"]')
                lines.append(f"    {nid} -->|No| {no_id}")
        else:
            label = esc(n.text)
            if n.inputs:
                label += f" [{', '.join(n.inputs)}]"
            lines.append(f'    {nid}["{label}"]')
            lines.append(f"    {prev} --> {nid}")
            prev = nid

    lines.append('    END(["END"])')
    lines.append(f"    {prev} --> END")
    return "\n".join(lines)
