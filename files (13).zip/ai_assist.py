"""Optional AI assistance for step interpretation only.

This module NEVER computes a number. Its only job is to help label steps that
the regex pipeline (pfd_pipeline.py) already extracted:
  - confirm/refine which steps are decision points
  - tag a short unit-operation label (Charging, Reaction, Work-up, Filtration,
    Crystallization, Drying, Distillation, Analysis) for readability

All molecular weights, quantities, scale-up, and the volume ledger are computed
by report_parser.py / pfd_pipeline.py / pfd_scaleup.py, which are deterministic
and produce the same result every run regardless of whether this module runs.
If this module fails or isn't used, nothing about the numbers changes.
"""

from __future__ import annotations

import json
import re


_SYSTEM = """You label chemistry process steps. You are given a numbered list of
process steps already extracted from a report. For EACH step number, return its
unit operation and whether it's a decision/IPC step. Do not change step text,
do not invent steps, do not compute or state any quantities.

Reply with JSON only: {"labels": [{"n": <step number>, "unit_op":
"Charging|Reaction|Work-up|Distillation|Filtration|Crystallization|Drying|Analysis",
"is_decision": <true|false>}]}"""


def label_steps(step_texts: list[tuple[int, str]], api_key: str,
                model: str = "llama-3.3-70b-versatile") -> dict[int, dict]:
    """step_texts: [(number, text), ...]. Returns {number: {'unit_op':.., 'is_decision':..}}.
    Raises on failure; caller should catch and just skip labeling."""
    from groq import Groq
    client = Groq(api_key=api_key)
    listing = "\n".join(f"{n}. {t}" for n, t in step_texts)
    resp = client.chat.completions.create(
        model=model,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": f"Steps:\n{listing}\n\nJSON:"},
        ],
    )
    raw = resp.choices[0].message.content
    raw = re.sub(r"^```(?:json)?", "", raw.strip()).strip()
    raw = re.sub(r"```$", "", raw).strip()
    data = json.loads(raw)
    return {int(item["n"]): {"unit_op": item.get("unit_op", ""),
                             "is_decision": bool(item.get("is_decision"))}
            for item in data.get("labels", [])}
