"""Streamlit app: generate a process flow diagram from a PR&D report,
plus reactor/filter/dryer equipment selection."""

import io
import re

import pandas as pd
import streamlit as st
from openpyxl.utils import get_column_letter

import pfd_pipeline as pfd
import pfd_scaleup as scaleup
import report_parser as rparse
import pfd_ctgr_writer as ctgr
import pfd_flowchart as flowchart
import equipment_db as eqdb
import reactor_select as rsel

st.set_page_config(page_title="PFD Generator", layout="wide")


def _render_mermaid(code: str, height: int = 600):
    """Render a Mermaid diagram in the app via mermaid.js (CDN)."""
    import streamlit.components.v1 as components
    html = f"""
    <div class="mermaid">{code}</div>
    <script type="module">
      import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs';
      mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
    </script>
    """
    components.html(html, height=height, scrolling=True)
def load_reactor_data(filepath):
    """Load a reactor master list using the general equipment_db loader, which
    scans all sheets and auto-detects columns (works with PB-8/CTO3/kilo-lab
    style files). Returns the dataframe shape filter_reactors() expects."""
    equipment = eqdb.load_equipment(filepath)
    reactors = [e for e in equipment if eqdb.is_reactor(e)]
    if not reactors:
        st.error("No reactor rows found in this file.")
        return pd.DataFrame()

    rows = []
    for e in reactors:
        moc = e.moc.strip().upper() if e.moc else re.sub(r"[^A-Za-z].*", "", e.eq_id).upper()
        moc = moc.replace("ALL GLASS", "GLR") or "GLR"
        rows.append({
            "reactor id": e.eq_id,
            "max volume": e.capacity_l,
            "min stirring": e.min_stir_l or 0,
            "min sensing": e.min_sense_l or 0,
            "agitator": (e.agitator or "").upper(),
            "materials": [m.strip() for m in moc.split("/")],
            "thermal options": ["ANY"],
        })
    return pd.DataFrame(rows)


def load_filter_data(uploaded_file):
    df = pd.read_excel(uploaded_file)
    df.columns = df.columns.str.strip().str.lower()
    return df


def load_dryer_data(uploaded_file):
    df = pd.read_excel(uploaded_file)
    df.columns = df.columns.str.strip().str.lower()
    return df.rename(columns={"dryer id": "equipment id"})


def _allowed_moc(ph, user_input):
    if ph == "basic":
        return ["SSR", "HAR", "HALAR"]
    if ph == "acidic":
        return ["GLR", "HALAR", "HAR"]
    if ph == "neutral":
        return ["GLR", "SSR", "HAR", "HALAR"]
    if ph == "coupon":
        mat = user_input["coupon_materials"][0].strip().upper()
        if user_input["corrosion_rate"] < 0.1:
            return [mat]
        st.error("Corrosion rate too high for this material.")
        return []
    return []


def filter_reactors(df, user_input, first_step_vol, total_vol):
    df = df[(df["min sensing"] <= first_step_vol) & (df["min stirring"] <= first_step_vol)]
    vol_limit = 0.7 if user_input["process_type"] in ["distillation", "reaction", "pressurized"] else 0.95
    df = df[df["max volume"] * vol_limit >= total_vol]

    allowed = _allowed_moc(user_input["ph_condition"], user_input)
    if not allowed:
        return pd.DataFrame()
    # reactor MOC uses GLR/SSR/HAR (no HALAR); intersect with reactor vocabulary
    reactor_allowed = [m for m in allowed if m in {"GLR", "SSR", "HAR"}]
    df = df[df["materials"].apply(lambda mats: any(m in mats for m in reactor_allowed))]

    temp = user_input["temperature"]
    if 10 <= temp <= 20:
        thermal = ["CHB"]
    elif 20 < temp <= 35:
        thermal = ["CT"]
    elif 35 < temp <= 90:
        thermal = ["HW"]
    else:
        thermal = ["LPS", "HOT OIL", "EJECTION CONDENSATE"]
    df = df[df["thermal options"].apply(
        lambda opts: "ANY" in opts or any(t in opts for t in thermal))]

    preferred = []
    if user_input["reaction_nature"] == "homogeneous":
        preferred = ["PROPELLOR", "PBT", "RCI", "ANCHOR", "CBRT"]
    elif user_input["reaction_nature"] == "heterogeneous":
        st_ = user_input["reaction_subtype"]
        if st_ == "biphasic":
            preferred = ["PROPELLOR", "PBT", "CBRT", "RCI"]
        elif st_ == "solid-liquid":
            preferred = ["PROPELLOR", "PBT", "CBRT", "RCI", "ANCHOR"]
        elif st_ == "gas-liquid":
            preferred = ["RUSTON", "DISC"]

    df = df.copy()
    df["Preference Match"] = df["agitator"].apply(
        lambda a: "yes" if any(p in a for p in preferred) else "warning")
    return df


def filter_filters(df, user_input, filter_types_required):
    allowed = _allowed_moc(user_input["ph_condition"], user_input)
    if not allowed:
        return pd.DataFrame()
    df = df[df["moc"].astype(str).str.upper().isin(allowed)]

    volume_litres = (user_input["mass"] / user_input["bulk_density"] * 1000
                     if user_input["bulk_density"] > 0 else 0)
    st.write(f"Volume required (L): {volume_litres:.2f}")

    if "cake capacity" not in df.columns:
        st.error("'cake capacity' column not found in the uploaded Excel.")
        return pd.DataFrame()
    df = df[df["cake capacity"] * 0.9 >= volume_litres]

    if not filter_types_required:
        st.warning("No filter type matched the selected filter property.")
        return pd.DataFrame()
    if "filter type" not in df.columns:
        st.error("'filter type' column not found in the uploaded Excel.")
        return pd.DataFrame()
    df = df.copy()
    df["filter type"] = df["filter type"].astype(str).str.upper()
    return df[df["filter type"].apply(lambda x: any(f in x for f in filter_types_required))]


def filter_dryers(df, user_input):
    allowed = _allowed_moc(user_input["ph_condition"], user_input)
    if not allowed:
        return pd.DataFrame()
    df = df[df["moc"].astype(str).str.upper().isin(allowed)]
    st.write(f"Volume required (L): {user_input['volume']:.2f}")
    if "capacity" not in df.columns:
        st.error("'capacity' column not found in the uploaded Excel.")
        return pd.DataFrame()
    return df[df["capacity"] * 0.9 >= user_input["volume"]]


def collect_unit_operation(unit_op_id):
    steps, total_volume, first_step_volume = [], 0.0, None
    st.subheader("Add Steps to Unit Operation")
    n = st.number_input("How many steps in this unit operation?",
                        min_value=1, max_value=30, value=1, key=f"nsteps_{unit_op_id}")
    for i in range(1, int(n) + 1):
        st.markdown(f"### Step {i}")
        c1, c2, c3 = st.columns(3)
        operation = c1.selectbox("Operation", ["charge", "addition"], key=f"op_{unit_op_id}_{i}")
        material = c2.selectbox("Material", ["reagent 1", "reagent 2", "reagent 3", "KSM", "solvent"],
                                key=f"mat_{unit_op_id}_{i}")
        volume = c3.number_input("Volume (L)", min_value=0.0, key=f"vol_{unit_op_id}_{i}")
        actual = volume
        if material == "KSM":
            pct = st.number_input("KSM %", min_value=0.0, max_value=100.0, key=f"ksm_{unit_op_id}_{i}")
            if pct > 0:
                actual = volume / (pct / 100)
        if first_step_volume is None:
            first_step_volume = actual
        total_volume += actual
        steps.append({"unit_op": unit_op_id, "step": i, "operation": operation,
                      "material": material, "input_volume": volume,
                      "actual_volume": actual, "accumulated_volume": total_volume})
    return first_step_volume, total_volume, steps


def export_steps_to_excel(steps_by_unitop):
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        rows = []
        for uid, (steps, reactor) in enumerate(steps_by_unitop, start=1):
            for s in steps:
                rows.append({
                    "Unit Operation": uid, "Operation": s["operation"],
                    "Material": s["material"], "Volume Added (L)": s["actual_volume"],
                    "Accumulated Volume (L)": s["accumulated_volume"], "Equipment": reactor})
        df = pd.DataFrame(rows)
        df.to_excel(writer, index=False, sheet_name="Steps")
        ws = writer.sheets["Steps"]
        for col in ws.columns:
            width = max((len(str(c.value)) if c.value else 0) for c in col) + 2
            ws.column_dimensions[get_column_letter(col[0].column)].width = width
    buffer.seek(0)
    return buffer


# ==========================================================================
#  Equipment selection
def tab_equipment():
    st.title("Process Engineering Automation")

    if "selections" not in st.session_state:
        st.session_state.selections = []

    with st.sidebar:
        st.header("Unit Operation Steps")
        if st.session_state.selections:
            for i, (log, sel) in enumerate(st.session_state.selections):
                st.markdown(f"### Step {i + 1}")
                for step in log:
                    st.markdown(f"- **Op:** {step.get('operation','N/A')} | "
                                f"**Mat:** {step.get('material','N/A')} | "
                                f"**Vol:** {step.get('actual_volume',0)} L")
                st.markdown(f"**Selected Equipment:** {sel}")
                if st.button(f"Remove Step {i + 1}", key=f"remove_{i}"):
                    st.session_state.selections.pop(i)
                    st.rerun()
        else:
            st.info("No unit operations added yet.")

    uploaded_file = st.file_uploader("Upload reactor database", type="xlsx")
    if not uploaded_file:
        st.info("Upload the reactor database to start.")
        return

    df = load_reactor_data(uploaded_file)
    if df.empty:
        return

    batch_id = len(st.session_state.selections) + 1
    st.header("Enter Process Conditions")
    st.markdown(f"## Unit Operation {batch_id}")

    unit_op_type = st.selectbox("Unit operation type",
                                ["reaction", "distillation", "pressurized",
                                 "extraction/workup", "filtration", "drying"],
                                key=f"unit_type_{batch_id}")
    ph_condition = st.selectbox("pH condition", ["basic", "acidic", "neutral", "coupon"],
                                key=f"ph_{batch_id}")
    corrosion_rate, coupon_materials = 0.0, []
    if ph_condition == "coupon":
        corrosion_rate = st.number_input("Corrosion rate (mm/year)", min_value=0.0, key=f"cr_{batch_id}")
        coupon_materials = [st.text_input("Coupon material", key=f"cm_{batch_id}").upper()]
    temperature = st.number_input("Process temperature (°C)", key=f"temp_{batch_id}")

    if unit_op_type not in ["filtration", "drying"]:
        reaction_nature = st.selectbox("Nature of reaction", ["none", "homogeneous", "heterogeneous"],
                                       key=f"rn_{batch_id}")
        reaction_subtype = None
        if reaction_nature == "heterogeneous":
            reaction_subtype = st.selectbox("Subtype", ["biphasic", "solid-liquid", "gas-liquid"],
                                            key=f"rs_{batch_id}")
        st.markdown("---")
        first_vol, total_vol, log = collect_unit_operation(batch_id)
        if st.button(f"Submit Unit Operation {batch_id}", key=f"submit_{batch_id}"):
            ui = {"process_type": unit_op_type, "ph_condition": ph_condition,
                  "corrosion_rate": corrosion_rate, "coupon_materials": coupon_materials,
                  "temperature": temperature, "reaction_nature": reaction_nature,
                  "reaction_subtype": reaction_subtype}
            matched = filter_reactors(df.copy(), ui, first_vol, total_vol)
            if not matched.empty:
                st.success(f"Reactors matching Unit Operation {batch_id}")
                view = matched[["reactor id", "min sensing", "min stirring",
                                "max volume", "agitator", "Preference Match"]]
                st.dataframe(view.style.applymap(
                    lambda v: "background-color:#d4edda" if v == "yes"
                    else ("background-color:#fff3cd" if v == "warning" else ""),
                    subset=["Preference Match"]))
                sel = st.selectbox("Select one reactor:", view["reactor id"].tolist(),
                                   key=f"sel_reactor_{batch_id}")
                st.session_state.selections.append((log, sel))
            else:
                st.warning("No matching reactors found.")

    elif unit_op_type == "filtration":
        f = st.file_uploader(f"Upload Filter Database (UO {batch_id})", type=["xlsx"],
                             key=f"upf_{batch_id}")
        if f:
            fdf = load_filter_data(f)
            mass = st.number_input("Mass (kg)", min_value=0.0, key=f"mass_{batch_id}")
            bd = st.number_input("Bulk density (kg/m³)", min_value=0.0, key=f"bd_{batch_id}")
            prop = st.selectbox("Filter property",
                                ["specific cake resistance (m/kg)", "rate of cake buildup", "settling rate"],
                                key=f"fp_{batch_id}")
            req = []
            if prop == "specific cake resistance (m/kg)":
                v = st.number_input("Specific cake resistance (m/kg)", min_value=0.0, key=f"scr_{batch_id}")
                if 1e7 <= v < 1e8:
                    req = ["CENTRIFUGE", "NUTSCHE"]
                elif 1e8 <= v < 1e10:
                    req = ["CENTRIFUGE", "ANFD", "RPF", "VNF"]
                elif v >= 1e10:
                    req = ["CENTRIFUGE", "NUTSCHE"]
            elif prop == "rate of cake buildup":
                unit = st.selectbox("Unit", ["cm/sec", "cm/min", "cm/hr"], key=f"bu_{batch_id}")
                v = st.number_input(f"Rate ({unit})", min_value=0.0, key=f"buv_{batch_id}")
                if unit == "cm/sec" and 0.1 <= v <= 10:
                    req = ["CENTRIFUGE", "NUTSCHE"]
                elif unit == "cm/min" and 0.1 <= v <= 10:
                    req = ["CENTRIFUGE", "ANFD", "RPF"]
                elif unit == "cm/hr" and 0.1 <= v <= 10:
                    req = ["ANFD"]
            else:
                v = st.number_input("Settling rate (cm/sec)", min_value=0.0, key=f"sr_{batch_id}")
                if v > 5:
                    req = ["CENTRIFUGE", "NUTSCHE"]
                elif 0.1 <= v <= 5:
                    req = ["ANFD", "RPF"]
                elif v < 0.1:
                    req = ["ANFD"]
            if st.button(f"Submit Filtration {batch_id}", key=f"subf_{batch_id}"):
                ui = {"ph_condition": ph_condition, "corrosion_rate": corrosion_rate,
                      "coupon_materials": coupon_materials, "temperature": temperature,
                      "bulk_density": bd, "mass": mass}
                matched = filter_filters(fdf.copy(), ui, req)
                if not matched.empty:
                    st.success("Matching filters found")
                    st.dataframe(matched)
                    id_col = next((c for c in matched.columns
                                   if c.strip().lower() in ["equipment id", "filter id", "id"]), None)
                    opts = matched[id_col].astype(str).tolist() if id_col else matched.index.astype(str).tolist()
                    sel = st.selectbox("Select filter:", opts, key=f"self_{batch_id}")
                    vol = mass / bd * 1000 if bd > 0 else 0
                    st.session_state.selections.append(
                        ([{"unit_op": batch_id, "operation": "filtration", "material": "N/A",
                           "input_volume": 0, "actual_volume": vol, "accumulated_volume": vol}], sel))
                else:
                    st.warning("No matching filters found.")

    elif unit_op_type == "drying":
        d = st.file_uploader(f"Upload Dryer Database (UO {batch_id})", type=["xlsx"], key=f"upd_{batch_id}")
        if d:
            ddf = load_dryer_data(d)
            vol = st.number_input("Volume (L)", min_value=0.0, key=f"vd_{batch_id}")
            if st.button(f"Submit Drying {batch_id}", key=f"subd_{batch_id}"):
                ui = {"ph_condition": ph_condition, "corrosion_rate": corrosion_rate,
                      "coupon_materials": coupon_materials, "temperature": temperature, "volume": vol}
                matched = filter_dryers(ddf.copy(), ui)
                if not matched.empty:
                    st.success("Matching dryers found")
                    st.dataframe(matched)
                    col = "equipment id" if "equipment id" in matched.columns else matched.columns[0]
                    sel = st.selectbox("Select dryer:", matched[col].astype(str).tolist(), key=f"seld_{batch_id}")
                    st.session_state.selections.append(
                        ([{"unit_op": batch_id, "operation": "drying", "material": "N/A",
                           "input_volume": 0, "actual_volume": vol, "accumulated_volume": vol}], sel))
                else:
                    st.warning("No matching dryers found.")

    if st.session_state.selections:
        buf = export_steps_to_excel(st.session_state.selections)
        st.download_button("Download Steps Summary", data=buf.getvalue(),
                           file_name="unit_op_steps.xlsx")


# ==========================================================================
#  PFD generator
# ==========================================================================


# ==========================================================================
#  PFD tab — upload report -> generate PFD
# ==========================================================================
def tab_pfd():
    st.header("Generate PFD from report")
    st.write("Upload a PR&D report (PDF or Word). The app reads the raw-material "
             "table and molecular weights, applies the product and yield you enter, "
             "and builds the flow diagram.")

    report = st.file_uploader("Report (PDF or Word)", type=["pdf", "docx"])
    equip_file = st.file_uploader(
        "Equipment list (optional, CTO3 block sheet .xlsx) — to auto-fit a GLR reactor",
        type=["xlsx", "xls"])

    col1, col2, col3 = st.columns(3)
    product = col1.text_input("Product name", value="")
    yield_pct = col2.number_input("Yield %", min_value=0.0, max_value=100.0, value=0.0,
                                  help="Overrides the report's yield. Leave 0 to use "
                                       "the report's reported/theoretical yield.")
    desired_output = col3.number_input(
        "Desired output (Kg)", min_value=0.0, value=0.0,
        help="Target product weight at plant scale. The app back-calculates the "
             "input batch size and scale-up ratio from this, using the yield and "
             "molecular weights. Leave 0 to use the report quantities as-is.")

    colm1, colm2 = st.columns(2)
    input_mw_in = colm1.number_input(
        "Input MW (0 = auto-read)", min_value=0.0, value=0.0,
        help="Molecular weight of the starting material. Leave 0 to read it from "
             "the report; set a value to override.")
    product_mw_in = colm2.number_input(
        "Product MW (0 = auto-read)", min_value=0.0, value=0.0,
        help="Molecular weight of the final product — often different from the "
             "starting material. Leave 0 to read it from the report; set to override.")

    col4, col5 = st.columns(2)
    fill = col4.slider("Max reactor fill factor", 0.5, 0.95, 0.8, 0.05,
                       help="Peak working volume must stay below capacity × this factor.")
    glr_only = col5.checkbox("GLR reactors only", value=True)

    mode = st.radio(
        "Output style",
        ["Flow diagram only", "Flow diagram + numbers",
         "Detailed table (formula-linked)", "Full template (4 sections)"],
        horizontal=True,
        help="Flow diagram = clean boxes/diamonds/arrows. "
             "+ numbers adds mass balance, material table, volume ledger. "
             "Detailed table = formula-linked engineering sheet. "
             "Full template = header + materials + flowchart with equipment blocks "
             "+ equipment summary, all formula-linked.")

    with st.expander("Smart recognition (optional Claude API key)"):
        api_key = st.text_input(
            "Anthropic API key", type="password", value="",
            help="With a key, the report is parsed by Claude for more accurate step, "
                 "decision and equipment-grouping recognition. Without it, the built-in "
                 "parser is used.")

    if report is None:
        return

    if st.button("Generate PFD", type="primary"):
        with st.spinner("Reading report…"):
            if report.name.lower().endswith(".docx"):
                parsed = rparse.parse_docx(report)
            else:
                parsed = rparse.parse_report(report)

        if not parsed:
            st.error("Could not read a raw-material table from this report. "
                     "If it is a scanned image PDF, the text can't be extracted.")
            return

        # load CTO3 reactor database if provided
        reactors = []
        if equip_file is not None:
            try:
                import tempfile
                with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tf:
                    tf.write(equip_file.getbuffer())
                    tmp_path = tf.name
                reactors = rsel.load_reactors(tmp_path)
                st.caption(f"Loaded {len(reactors)} reactors "
                           f"({sum(1 for r in reactors if r.is_glr)} GLR).")
            except Exception as ex:
                st.warning(f"Could not read equipment file: {ex}")

        yield_override = (yield_pct / 100.0) if yield_pct > 0 else None

        if desired_output <= 0:
            st.warning("Enter a **Desired output (Kg)** so the app can scale the "
                       "recipe to plant quantities. Without it, the numbers stay at "
                       "lab scale (grams/millilitres shown as kg/L).")

        stages = []
        for ps in parsed:
            sc = rparse.to_stage_calc(ps, scale_up_ratio=1.0,
                                      yield_override=yield_override, project=product)
            # molecular-weight overrides (product is usually a different compound)
            if input_mw_in > 0:
                sc.input_mw = input_mw_in
            if product_mw_in > 0:
                sc.product_mw = product_mw_in
            # reverse mode: back-calculate batch + ratio from the desired output
            if desired_output > 0:
                sc.desired_output_kg = desired_output
                sc.mass_ratio = None    # yield + MW drive the calc, not report ratio
            stages.append(sc)

        # if any MW is still missing, tell the user to fill it in
        missing = [sc.name for sc in stages
                   if not sc.input_mw or not sc.product_mw
                   or sc.input_mw <= 1 or sc.product_mw <= 1]
        if missing:
            st.warning("Molecular weight not found for: " + ", ".join(missing) +
                       ". Enter the Input MW / Product MW above and generate again "
                       "for an accurate mass balance.")

        scaleup.chain_stages(stages)

        for stage in stages:
            if not stage.steps:
                continue
            pfd.extract_conditions(stage.steps)
            mrows = [[m.sr_no, m.name, None, m.plant_kg, m.plant_l] for m in stage.materials]
            if mrows:
                mats = pfd.load_material_sheet(pd.DataFrame(mrows), name_col=1, kg_col=3, l_col=4)
                pfd.assign_materials(stage.steps, mats)
            pfd.compute_volumes(
                stage.steps,
                separate_overrides={s.number: 0.0 for s in pfd.separate_steps(stage.steps)})

            # reactor selection per stage using the mentor's rule:
            #   first working volume after the first charge, and peak working volume
            if reactors and stage.steps:
                vols = [s.max_vol for s in stage.steps if s.max_vol is not None]
                first_charge = next((s.max_vol for s in stage.steps
                                     if s.max_vol is not None and s.max_vol > 0), None)
                peak = max(vols) if vols else 0
                if first_charge and peak:
                    fits = rsel.select_reactors(reactors, first_charge, peak,
                                                fill_factor=fill, glr_only=glr_only)
                    if fits:
                        best = fits[0]
                        stage.reactor_id = best.eq_id
                        stage.reactor_capacity = best.capacity_l
                        stage.reactor_occupancy = peak / best.capacity_l
                        stage.reactor_options = [r.eq_id for r in fits[:5]]

        # show what was read, so the user can sanity-check
        for ps, sc in zip(parsed, stages):
            with st.expander(f"{sc.name} — data read from report", expanded=True):
                line = (f"Batch **{sc.plant_batch_kg:g} Kg** · "
                        f"moles **{sc.input_moles:.4g}** · "
                        f"yield **{sc.yield_frac:g}** · output **{sc.output_kg:.4g} Kg**")
                if getattr(sc, "reactor_id", None):
                    line += (f" · reactor **{sc.reactor_id}** "
                             f"({sc.reactor_capacity:g} L, "
                             f"{sc.reactor_occupancy*100:.0f}% full)")
                st.write(line)
                if getattr(sc, "reactor_options", None) and len(sc.reactor_options) > 1:
                    st.caption("Other reactors that fit: "
                               + ", ".join(sc.reactor_options[1:]))
                rows = [{"S.No": m.sr_no, "Material": m.name,
                         "Qty": m.lab_qty_g or m.lab_vol_ml,
                         "Unit": "g" if m.lab_qty_g else ("mL" if m.lab_vol_ml else ""),
                         "MW": m.mw, "Mole ratio": m.remarks,
                         "Plant Kg": round(m.plant_kg, 3) if m.plant_kg else None,
                         "Plant L": round(m.plant_l, 3) if m.plant_l else None}
                        for m in sc.materials]
                if rows:
                    st.dataframe(pd.DataFrame(rows), use_container_width=True)
                if not sc.materials:
                    st.warning("No raw-material table detected for this stage.")

        ratios = [getattr(s, "scale_up_ratio", 1.0) for s in stages]
        if mode == "Flow diagram only":
            data = flowchart.build_diagram(stages)
        elif mode == "Flow diagram + numbers":
            data = flowchart.build_with_numbers(stages)
        elif mode == "Full template (4 sections)":
            import smart_extractor as se
            import ctgr_template as ct
            # build SmartStages either via API or the fallback, aligned to computed stages
            report_for_llm = st.session_state.get("_report_text", "")
            smart_stages = None
            if api_key and report_for_llm:
                try:
                    smart_stages = se.extract_smart(report_for_llm, api_key)
                except Exception as ex:
                    st.warning(f"API extraction failed ({ex}); using built-in parser.")
            if not smart_stages:
                report.seek(0)
                smart_stages = se.extract_fallback(report, report.name)
            # fill MWs + tag material additions
            for ss, sc in zip(smart_stages, stages):
                ss.input_mw = ss.input_mw or sc.input_mw
                ss.product_mw = ss.product_mw or sc.product_mw
                ss.product = ss.product or product or sc.name
                ss.yield_frac = ss.yield_frac or sc.yield_frac
                for op in ss.operations:
                    if not op.materials_added:
                        for m in ss.materials:
                            if m.name and m.name.lower() in op.text.lower():
                                op.materials_added.append(m.name)
            bs = {ss.name: sc.plant_batch_kg for ss, sc in zip(smart_stages, stages)}
            rr = {ss.name: getattr(sc, "scale_up_ratio", 410.0) for ss, sc in zip(smart_stages, stages)}
            data = ct.build(smart_stages, batch_sizes=bs, scale_ratios=rr, equipment=reactors)
        else:
            data = ctgr.build(stages, ratios)
        st.success("PFD generated.")
        st.download_button("Download PFD (Excel)", data=data, file_name="PFD.xlsx",
                           type="primary",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def tab_flowmaker():
    st.header("Flow Diagram Maker")
    st.write("Upload any Word, PDF or Excel file. The app finds the process steps "
             "(under a heading like Procedure, Process, Operations, Method or Steps) "
             "and draws a flow diagram with decision boxes and Yes / No branches.")

    up = st.file_uploader("Document (Word / PDF / Excel)",
                          type=["docx", "pdf", "xlsx", "xls", "xlsm", "csv"], key="fm_up")
    title = st.text_input("Diagram title", value="PROCESS FLOW DIAGRAM", key="fm_title")

    if up is None:
        return

    if st.button("Generate flow diagram", type="primary", key="fm_go"):
        import flow_extractor as fe
        import flow_writer as fw
        with st.spinner("Reading document…"):
            steps = fe.extract_steps(up, up.name)

        if not steps:
            st.error("No steps found. Make sure the file has a numbered or bulleted "
                     "list of steps, or a Procedure/Process/Steps section.")
            return

        st.success(f"Found {len(steps)} steps "
                   f"({sum(1 for s in steps if s.is_decision)} decision points).")
        st.dataframe(pd.DataFrame([{
            "Step": s.number, "Type": "Decision" if s.is_decision else "Operation",
            "Text": s.text,
            "Yes →": s.yes_text if s.is_decision else "",
            "No →": s.no_text if s.is_decision else "",
        } for s in steps]), use_container_width=True)

        data = fw.build(steps, title=title or "PROCESS FLOW DIAGRAM")
        st.download_button("Download flow diagram (Excel)", data=data,
                           file_name="flow_diagram.xlsx", type="primary",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def tab_ai_flowsheet():
    st.header("AI Flowsheet")
    st.write("Upload any document — Word, PDF, Excel or text. If the report has "
             "multiple stages (e.g. CGTR1/CGTR2/CGTR3), each one is detected and "
             "processed separately so no stage gets missed or merged into another. "
             "The AI identifies steps, decisions and streams; this app computes "
             "every number — plant quantities, moles, W/w, V/W, output and the "
             "running volume ledger — deterministically, so the same report always "
             "gives the same numbers.")

    up = st.file_uploader("Document", type=["docx", "pdf", "xlsx", "xls", "csv", "txt"],
                          key="ai_up")

    col1, col2 = st.columns(2)
    batch_kg = col1.number_input(
        "Plant batch size for Stage 1 (Kg)", min_value=0.0, value=41.0,
        help="Later stages use the previous stage's output as their batch size, "
             "same as the reference sheet.")
    sm_lab_g = col2.number_input(
        "Lab-scale starting material for Stage 1 (g)", min_value=0.0, value=100.0,
        help="Scale-up ratio = batch × 1000 / this, applied to Stage 1's materials.")

    key = st.text_input("Groq API key", type="password", key="ai_key",
                        help="Optional. Without a key, a built-in parser is used — "
                             "fully deterministic, same report always gives the same steps.")

    if up is None:
        return

    if st.button("Build flowsheet", type="primary", key="ai_go"):
        import flowsheet_ai as fa
        with st.spinner("Reading document…"):
            if up.name.lower().endswith(".txt"):
                text = up.read().decode("utf-8", "ignore")
            else:
                text = fa.read_text(up, up.name)

        if not text.strip():
            st.error("No readable text found in this file.")
            return

        stage_chunks = fa.split_stages(text)
        st.caption(f"Detected {len(stage_chunks)} stage(s): "
                   + ", ".join(name for name, _ in stage_chunks))

        sheets = []
        for name, chunk in stage_chunks:
            sh = None
            if key:
                try:
                    with st.spinner(f"AI is analysing {name}…"):
                        sh = fa.extract_with_ai(chunk, key)
                except Exception as ex:
                    st.warning(f"{name}: AI extraction failed ({ex}). "
                              "Using the built-in parser for this stage.")
            if sh is None:
                sh = fa.extract_fallback(chunk)
            if not sh.title or sh.title == "Process":
                sh.title = name
            sh.stage_name = name
            sheets.append(sh)

        empty = [sh.stage_name for sh in sheets if not sh.nodes]
        if empty:
            st.warning(f"No steps found for: {', '.join(empty)}. "
                      "Check that this stage has a clear Procedure/Process heading.")
        sheets = [sh for sh in sheets if sh.nodes]
        if not sheets:
            st.error("No process steps could be identified in this document.")
            return

        # ---- deterministic mass balance + ledger, chained stage to stage ----
        running_batch = batch_kg
        running_lab = sm_lab_g
        for sh in sheets:
            fa.compute(sh, batch_size_kg=running_batch, sm_lab_g=running_lab)
            running_batch = sh.balance.get("output_kg") or running_batch
            running_lab = 100.0   # subsequent stages default to a 100 g lab basis

        for sh in sheets:
            st.markdown(f"### {sh.stage_name}: {sh.title}")
            st.caption(f"{len(sh.nodes)} steps, "
                      f"{sum(1 for n in sh.nodes if n.kind=='decision')} decision points.")

            bal = sh.balance or {}
            if any(v for v in bal.values() if v is not None):
                c1, c2, c3, c4 = st.columns(4)
                if bal.get("input_kg"): c1.metric("Batch", f"{bal['input_kg']:.2f} kg")
                if bal.get("yield"): c2.metric("Yield", f"{bal['yield']*100:.1f}%")
                if bal.get("output_kg"): c3.metric("Output", f"{bal['output_kg']:.2f} kg")
                if bal.get("scale_up_ratio"): c4.metric("Ratio", f"{bal['scale_up_ratio']:.0f}")

            st.dataframe(pd.DataFrame([{
                "#": n.idx, "Type": n.kind, "Step": n.text,
                "Unit op": n.unit_op, "Charges": ", ".join(n.inputs),
                "Min L": round(n.vol_in, 1) if n.vol_in is not None else "",
                "Max L": round(n.vol_out, 1) if n.vol_out is not None else "",
                "Yes": n.yes, "No": n.no} for n in sh.nodes]),
                use_container_width=True)

            if sh.streams:
                def _r(v, n=2): return round(v, n) if isinstance(v, (int, float)) else v
                st.dataframe(pd.DataFrame([{
                    "Stream": s.name, "Lab Qty": s.qty, "Unit": s.unit,
                    "Plant Kg": _r(s.plant_kg), "Plant L": _r(s.plant_l),
                    "MW": s.mw, "Moles": _r(s.moles, 4),
                    "W/w": _r(s.ww), "V/W": _r(s.vw),
                    "Density": s.density, "Role": s.role}
                    for s in sh.streams]), use_container_width=True)

            mermaid_code = fa.to_mermaid(sh)
            with st.expander(f"Flow diagram — {sh.stage_name}"):
                _render_mermaid(mermaid_code, height=400)
            st.divider()

        data = fa.render_all(sheets)
        st.download_button("Download flowsheet (Excel, all stages)", data=data,
                           file_name="flowsheet.xlsx", type="primary",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def main():
    tab_a, tab0, tab1, tab2 = st.tabs(
        ["AI Flowsheet", "Flow Diagram Maker", "PFD Generator (with numbers)",
         "Equipment Selection"])
    with tab_a:
        tab_ai_flowsheet()
    with tab0:
        tab_flowmaker()
    with tab1:
        tab_pfd()
    with tab2:
        tab_equipment()


if __name__ == "__main__":
    main()
