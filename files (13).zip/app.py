"""PFD Generator - single tool.

Upload a process report (Word/PDF), enter the desired output, get back a
formula-linked PFD with the mass balance, raw-material table and the running
volume ledger — computed deterministically every time.

AI (optional, Groq) is used ONLY to label steps (unit operation, decision
yes/no) for readability. Every number - plant quantities, moles, W/w, V/W,
scale-up ratio, output, and the volume ledger - comes from report_parser.py /
pfd_pipeline.py / pfd_scaleup.py, which are plain deterministic Python. The
same report with the same inputs always produces the same numbers, whether or
not an API key is supplied.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

import report_parser as rparse
import pfd_pipeline as pfd
import pfd_ctgr_writer as ctgr
import pfd_flowchart as flowchart
import reactor_select as rsel

st.set_page_config(page_title="PFD Generator", layout="wide")


def main():
    st.title("PFD Generator")
    st.caption("Upload a report → get a formula-linked flow diagram with the "
              "mass balance and volume ledger. The numbers are computed the "
              "same way every time; AI (optional) is only used to label steps.")

    report = st.file_uploader("Process report (PDF or Word)", type=["pdf", "docx"])
    equip_file = st.file_uploader(
        "Equipment list (optional, CTO3 I-E block .xlsx) — to auto-fit a reactor",
        type=["xlsx", "xls"])

    col1, col2, col3 = st.columns(3)
    product = col1.text_input("Product name", value="")
    yield_pct = col2.number_input(
        "Yield % (0 = use the report's yield)", min_value=0.0, max_value=100.0, value=0.0)
    desired_output = col3.number_input(
        "Desired output (Kg)", min_value=0.0, value=0.0,
        help="Target product weight. The batch size and scale-up ratio are "
             "back-calculated from this using the yield and molecular weights.")

    colm1, colm2 = st.columns(2)
    input_mw_in = colm1.number_input("Input MW (0 = auto-read from report)",
                                     min_value=0.0, value=0.0)
    product_mw_in = colm2.number_input("Product MW (0 = auto-read from report)",
                                       min_value=0.0, value=0.0,
                                       help="Often different from the input MW — "
                                            "the product is usually a different compound.")

    col4, col5 = st.columns(2)
    fill = col4.slider("Max reactor fill factor", 0.5, 0.95, 0.8, 0.05)
    glr_only = col5.checkbox("GLR reactors only", value=True)

    with st.expander("AI step labeling (optional)"):
        st.caption("Labels each step's unit operation and whether it's a decision "
                  "point, for readability only. It never changes a number — the "
                  "mass balance and volume ledger are always computed the same "
                  "deterministic way, with or without this.")
        api_key = st.text_input("Groq API key", type="password")

    if report is None:
        return

    if st.button("Generate PFD", type="primary"):
        with st.spinner("Reading report…"):
            parsed = (rparse.parse_docx(report) if report.name.lower().endswith(".docx")
                      else rparse.parse_report(report))

        if not parsed:
            st.error("Could not read a raw-material table from this report. "
                     "If it's a scanned image PDF, text can't be extracted.")
            return

        st.caption(f"Detected {len(parsed)} stage(s): " + ", ".join(p.name for p in parsed))
        empty = [p.name for p in parsed if not p.steps]
        if empty:
            st.warning(f"No steps found for: {', '.join(empty)}. Check that stage "
                      "has a clear Procedure/Process section.")

        reactors = []
        if equip_file is not None:
            try:
                import tempfile
                with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tf:
                    tf.write(equip_file.getbuffer())
                    tmp_path = tf.name
                reactors = rsel.load_reactors(tmp_path)
                st.caption(f"Loaded {len(reactors)} reactors "
                          f"({sum(1 for r in reactors if r.is_glr)} GLR).")
            except Exception as ex:
                st.warning(f"Could not read equipment file: {ex}")

        yield_override = (yield_pct / 100.0) if yield_pct > 0 else None

        stages = []
        for ps in parsed:
            sc = rparse.to_stage_calc(ps, scale_up_ratio=1.0,
                                      yield_override=yield_override, project=product)
            if input_mw_in > 0:
                sc.input_mw = input_mw_in
            if product_mw_in > 0:
                sc.product_mw = product_mw_in
            if desired_output > 0:
                sc.desired_output_kg = desired_output
                sc.mass_ratio = None
            stages.append(sc)

        missing_mw = [sc.name for sc in stages
                     if not sc.input_mw or not sc.product_mw
                     or sc.input_mw <= 1 or sc.product_mw <= 1]
        if missing_mw:
            st.warning("Molecular weight not found for: " + ", ".join(missing_mw) +
                      ". Enter Input MW / Product MW above and generate again "
                      "for an accurate mass balance.")

        from pfd_scaleup import chain_stages
        chain_stages(stages)

        # ---- deterministic per-stage pipeline: THIS computes every number ----
        for stage in stages:
            if not stage.steps:
                continue
            pfd.extract_conditions(stage.steps)          # regex decision detection
            mrows = [[m.sr_no, m.name, None, m.plant_kg, m.plant_l]
                    for m in stage.materials]
            if mrows:
                mats = pfd.load_material_sheet(pd.DataFrame(mrows),
                                               name_col=1, kg_col=3, l_col=4)
                pfd.assign_materials(stage.steps, mats)   # keyword material-to-step match
            pfd.compute_volumes(                          # tested ledger logic
                stage.steps,
                separate_overrides={s.number: 0.0 for s in pfd.separate_steps(stage.steps)})

            # optional AI labeling - readability only, no numbers touched
            if api_key and stage.steps:
                try:
                    import ai_assist
                    labels = ai_assist.label_steps(
                        [(s.number, s.text) for s in stage.steps], api_key)
                    for s in stage.steps:
                        lbl = labels.get(s.number)
                        if lbl:
                            s.unit_op = lbl.get("unit_op", "")
                except Exception as ex:
                    st.caption(f"AI labeling skipped for {stage.name}: {ex}")

            # reactor selection (mentor's rule: GLR only, thermowell-without-stir
            # minimum, peak volume under capacity x fill factor)
            if reactors and stage.steps:
                vols = [s.max_vol for s in stage.steps if s.max_vol is not None]
                first_charge = next((s.max_vol for s in stage.steps
                                     if s.max_vol is not None and s.max_vol > 0), None)
                peak = max(vols) if vols else 0
                if first_charge and peak:
                    fits = rsel.select_reactors(reactors, first_charge, peak,
                                                fill_factor=fill, glr_only=glr_only)
                    if fits:
                        stage.reactor_id = fits[0].eq_id
                        stage.reactor_capacity = fits[0].capacity_l
                        stage.reactor_occupancy = peak / fits[0].capacity_l
                        stage.reactor_options = [r.eq_id for r in fits[:5]]

        # ---- display ----
        for sc in stages:
            if not sc.steps:
                continue
            st.markdown(f"### {sc.name}")
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Batch", f"{sc.plant_batch_kg:.2f} kg")
            c2.metric("Yield", f"{sc.yield_frac*100:.1f}%")
            c3.metric("Output", f"{sc.output_kg:.2f} kg")
            c4.metric("Scale-up ratio", f"{sc.scale_up_ratio:.0f}")

            if sc.reactor_id:
                line = f"Reactor: **{sc.reactor_id}** ({sc.reactor_capacity:.0f} L, " \
                      f"{sc.reactor_occupancy*100:.0f}% fill)"
                st.write(line)

            st.dataframe(pd.DataFrame([{
                "#": s.number, "Step": s.full_text,
                "Unit op": getattr(s, "unit_op", ""),
                "Materials": ", ".join(s.materials),
                "Min L": round(s.min_vol, 1) if s.min_vol is not None else "",
                "Max L": round(s.max_vol, 1) if s.max_vol is not None else "",
            } for s in sc.steps]), use_container_width=True)

            if sc.materials:
                st.dataframe(pd.DataFrame([{
                    "Sr": m.sr_no, "Material": m.name,
                    "Lab g": m.lab_qty_g, "Lab mL": m.lab_vol_ml,
                    "Plant Kg": round(m.plant_kg, 3) if m.plant_kg else None,
                    "Plant L": round(m.plant_l, 3) if m.plant_l else None,
                    "MW": m.mw, "Density": m.density, "Remarks": m.remarks,
                } for m in sc.materials]), use_container_width=True)
            st.divider()

        ratios = [getattr(s, "scale_up_ratio", 1.0) for s in stages]
        mode = st.radio("Output style", ["Flow diagram + numbers", "Formula-linked table"],
                        horizontal=True)
        data = (flowchart.build_with_numbers(stages) if mode == "Flow diagram + numbers"
               else ctgr.build(stages, ratios))
        st.download_button("Download PFD (Excel)", data=data, file_name="PFD.xlsx",
                           type="primary",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


if __name__ == "__main__":
    main()
