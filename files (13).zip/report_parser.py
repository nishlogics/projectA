"""Read a PR&D report (PDF or Word): extract process steps, the raw-material
table, molecular weights and yield."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from pfd_pipeline import extract_steps_from_lines, Step
from pfd_scaleup import RawMaterial, StageCalc


# ---------------------------------------------------------------------------
@dataclass
class ParsedStage:
    name: str
    raw_text: str
    steps: list[Step] = field(default_factory=list)
    materials: list[RawMaterial] = field(default_factory=list)
    input_mw: Optional[float] = None
    product_mw: Optional[float] = None
    yield_frac: Optional[float] = None
    lab_input_g: Optional[float] = None
    theo_out_g: Optional[float] = None      # report "theoretical yield: X g ..."
    theo_in_g: Optional[float] = None       # "... for Y g of input"


_STAGE_SPLIT = re.compile(
    r"(?im)^\s*(CGTR\s*\d|CTGR\s*\d|Stage[\s\-]*\d|.*Draft\s+process)\b")
_UNIT_SOLID = {"g", "gm", "gms", "kg", "grams"}
_UNIT_LIQ = {"ml", "mL", "l", "L", "litre", "liters"}


_TABLE_ROW_RE = re.compile(
    r"^\s*\d{1,3}\s+.+?\s+\d+(\.\d+)?\s+(g|gm|gms|ml|mL|kg|L)\b", re.IGNORECASE)


def _looks_like_table_row(line: str) -> bool:
    """True if a line is really a raw-material table row (e.g. '1 L-Tyrosine 100 g 181.19 ...')
    rather than a genuine numbered process step (e.g. '1. Charge water into the RBF')."""
    if _TABLE_ROW_RE.match(line):
        return True
    nums = re.findall(r"\d+\.\d+", line)
    return len(nums) >= 2 and not re.search(
        r"(?i)\b(charge|add|stir|cool|heat|adjust|maintain|filter|wash|dry|separate|"
        r"submit|raise|distill|unload|suck|release|stop|allow)\b", line)


def _to_float(x) -> Optional[float]:
    if x is None:
        return None
    s = re.sub(r"[^\d.\-]", "", str(x))
    if not s or s in {".", "-"}:
        return None
    try:
        return float(s)
    except ValueError:
        return None


# ---------------------------------------------------------------------------
def parse_report(file) -> list[ParsedStage]:
    """Main entry: PDF file-like -> list of ParsedStage (one per synthesis stage)."""
    import pdfplumber  # imported lazily so the app starts fast on a VDI
    with pdfplumber.open(file) as pdf:
        pages_text = [p.extract_text() or "" for p in pdf.pages]
        pages_tables = [p.extract_tables() or [] for p in pdf.pages]

    full_text = "\n".join(pages_text)
    stages = _split_stages(full_text)

    for st in stages:
        st.steps = extract_steps_from_lines(_procedure_lines(st.raw_text))
        st.input_mw, st.product_mw = _extract_mws(st.raw_text)
        st.yield_frac = _extract_yield(st.raw_text)
        st.theo_out_g, st.theo_in_g = _extract_theoretical(st.raw_text)
        st.lab_input_g = _extract_lab_input(st.raw_text)

    all_tables = [t for tbls in pages_tables for t in tbls]
    _assign_tables(stages, all_tables, pages_text, pages_tables)
    return stages


def parse_docx(file) -> list[ParsedStage]:
    """Parse a Word (.docx) report: paragraphs for text/steps, tables for materials."""
    from docx import Document

    doc = Document(file)
    full_text = "\n".join(p.text for p in doc.paragraphs)
    stages = _split_stages(full_text)

    for st in stages:
        st.steps = extract_steps_from_lines(_procedure_lines(st.raw_text))
        st.input_mw, st.product_mw = _extract_mws(st.raw_text)
        st.yield_frac = _extract_yield(st.raw_text)
        st.theo_out_g, st.theo_in_g = _extract_theoretical(st.raw_text)
        st.lab_input_g = _extract_lab_input(st.raw_text)

    # docx tables -> rows of strings
    doc_tables = []
    for t in doc.tables:
        grid = [[c.text for c in row.cells] for row in t.rows]
        doc_tables.append(grid)

    # assign every material table to the (single) or first stage
    target = stages[0] if stages else ParsedStage(name="Stage 1", raw_text=full_text)
    if not stages:
        stages = [target]
    for grid in doc_tables:
        mats = _parse_material_table(grid)
        if mats:
            target.materials.extend(mats)
    return stages


# ---------------------------------------------------------------------------
def _procedure_lines(text: str) -> list[str]:
    """Return only the lines belonging to the process procedure, dropping the
    raw-materials table and scheme so they don't leak into the step list.

    Starts at the first 'Process description' / 'Reaction procedure' heading (or
    the first genuine numbered charge/stir/cool step) and ends before the yield.
    """
    lines = text.splitlines()
    start = 0
    for i, ln in enumerate(lines):
        if re.search(r"(?i)\b(process description|reaction procedure)\b", ln):
            start = i + 1
            break
    else:
        # no explicit heading: begin at the first action-verb numbered step
        for i, ln in enumerate(lines):
            if re.match(r"(?i)^\s*\d{1,3}[.\)]\s*(charge|stir|cool|add|heat|"
                        r"maintain|adjust|filter|distill|dry|slowly)", ln):
                start = i
                break

    end = len(lines)
    for i in range(start, len(lines)):
        if re.search(r"(?i)\b(theoretical yield|reported yield)\b", lines[i]):
            end = i
            break
    return [ln for ln in lines[start:end] if not _looks_like_table_row(ln)]


def _split_stages(full_text: str) -> list[ParsedStage]:
    lines = full_text.splitlines()
    # Find each page/section's own stage heading, skipping the banner line that
    # lists all three stages (contains 'and' / multiple CGTR mentions).
    idxs = []
    for i, ln in enumerate(lines):
        low = ln.strip().lower()
        if "cgtr" not in low and "ctgr" not in low:
            continue
        if " and " in low or (low.count("cgtr") + low.count("ctgr")) > 1:
            continue  # banner
        m = re.search(r"(?i)(CGTR|CTGR)\s*([123])\b", ln)
        if m and re.search(r"(?i)(draft process|process description|scheme|synthetic)", ln):
            idxs.append((i, f"Stage{m.group(2)}"))

    if not idxs:
        return [ParsedStage(name="Stage1", raw_text=full_text)]

    seen = {}
    for pos, name in idxs:
        if name not in seen:
            seen[name] = pos
    ordered = sorted(seen.items(), key=lambda kv: kv[1])

    stages = []
    for k, (name, start) in enumerate(ordered):
        end = ordered[k + 1][1] if k + 1 < len(ordered) else len(lines)
        stages.append(ParsedStage(name=name, raw_text="\n".join(lines[start:end])))
    return stages


def _extract_mws(text: str) -> tuple[Optional[float], Optional[float]]:
    mws = [float(m) for m in re.findall(r"(?i)M\.?\s*Wt:?\s*([\d.]+)", text)]
    if not mws:
        return None, None
    return mws[0], mws[-1]  # first = SM/input, last = product


def _extract_yield(text: str) -> Optional[float]:
    """Return a yield fraction if the report states a reported %."""
    m = re.search(r"(?i)reported\s+yield:?\s*([\d.]+)\s*%", text)
    if m:
        return float(m.group(1)) / 100.0
    return None


def _extract_theoretical(text: str) -> tuple[Optional[float], Optional[float]]:
    """Return (theoretical_output_g, input_g) from
    'Theoretical yield: 48.6 g for 59.8 g of input.' -> (48.6, 59.8)."""
    m = re.search(r"(?i)theoretical\s+yield:?\s*([\d.]+)\s*g\s+for\s+([\d.]+)\s*g", text)
    if m:
        return float(m.group(1)), float(m.group(2))
    return None, None


def _extract_lab_input(text: str) -> Optional[float]:
    m = re.search(r"(?i)for\s+([\d.]+)\s*g\s+of\s+input", text)
    return float(m.group(1)) if m else None


# ---------------------------------------------------------------------------
def _assign_tables(stages, all_tables, pages_text, pages_tables):
    """Assign each extracted table to its stage.

    Real reports carry a common banner ('CGTR1, CGTR2 and CGTR3 Draft process')
    on every page, so we must NOT key off any CGTR mention. Instead we look for
    the page's specific stage heading — 'CGTRn Draft process' or
    'Synthetic scheme of CGTRn' — and fall back to sequential assignment when a
    page has a material table but no clear heading.
    """
    single = len(stages) == 1
    next_stage_idx = 0
    for pi, tbls in enumerate(pages_tables):
        if not tbls:
            continue
        ptxt = pages_text[pi]

        target = None
        if single:
            target = stages[0]
        else:
            stage_num = _page_stage_number(ptxt)
            if stage_num:
                target = next((s for s in stages if s.name == f"Stage{stage_num}"), None)

        for tbl in tbls:
            mats = _parse_material_table(tbl)
            if not mats:
                continue
            dest = target
            if dest is None:
                dest = next((s for s in stages if not s.materials), stages[-1])
            dest.materials.extend(mats)


def _page_stage_number(ptxt: str) -> Optional[str]:
    """Return '1'/'2'/'3' for the page's own stage heading, ignoring the common
    banner line (which lists all three, e.g. 'CGTR1, CGTR2 and CGTR3 ...')."""
    for line in ptxt.splitlines():
        ls = line.strip()
        low = ls.lower()
        if not low or ("cgtr" not in low and "ctgr" not in low):
            continue
        # skip the banner: it names more than one stage / contains 'and'
        if " and " in low or (low.count("cgtr") + low.count("ctgr")) > 1:
            continue
        m = re.search(r"(?i)(CGTR|CTGR)\s*([123])\b", ls)
        if m:
            return m.group(2)
    return None


# Molecular weights of common reagents/solvents that reports usually leave blank
# in the M.Wt column. Matched case-insensitively against the material name.
_COMMON_MW = {
    "water": 18.02, "hcl": 36.46, "conc hcl": 36.46, "hydrochloric acid": 36.46,
    "naoh": 40.00, "sodium hydroxide": 40.00, "koh": 56.11, "potassium hydroxide": 56.11,
    "ammonia": 17.03, "aq ammonia": 17.03, "ammonium hydroxide": 35.05,
    "ammonium bicarbonate": 79.06, "ammonium chloride": 53.49,
    "sodium bicarbonate": 84.01, "sodium carbonate": 105.99,
    "sodium chloride": 58.44, "brine": 58.44,
    "acetic acid": 60.05, "sulphuric acid": 98.08, "sulfuric acid": 98.08,
    "methanol": 32.04, "ethanol": 46.07, "ipa": 60.10, "isopropyl alcohol": 60.10,
    "acetone": 58.08, "toluene": 92.14, "ethyl acetate": 88.11, "dcm": 84.93,
    "dichloromethane": 84.93, "thf": 72.11, "acetonitrile": 41.05,
    "chloroacetyl chloride": 112.94, "chloro acetyl chloride": 112.94,
    "acetic anhydride": 102.09, "l-tyrosine": 181.19,
}


def _lookup_mw(name: str) -> Optional[float]:
    """Return a known molecular weight for a common reagent, else None.
    Cleans the name (drops 'lot-1', '28%', 'aq', 'solution', etc.) then matches."""
    n = name.strip().lower()
    n = re.sub(r"\blot[\s\-]*\d+\b", "", n)
    n = re.sub(r"\b\d+\s*%\b", "", n)
    n = re.sub(r"\b(aq|aqueous|solution|conc\.?|dry|wet)\b", "", n)
    n = re.sub(r"[^\w\s]", " ", n)
    n = re.sub(r"\s+", " ", n).strip()
    if n in _COMMON_MW:
        return _COMMON_MW[n]
    for key, mw in _COMMON_MW.items():
        if key in n or n in key:
            return mw
    return None


def _parse_material_table(tbl: list[list]) -> list[RawMaterial]:
    """Turn a raw pdfplumber table into RawMaterial rows.
    Expected columns (order tolerant): S.No | Raw Material | Qty | Unit | M.Wt | Mol | Mole Ratio | Remarks
    """
    if not tbl or len(tbl) < 2:
        return []

    # locate header row
    header = None
    for r in tbl[:3]:
        joined = " ".join((c or "").lower() for c in r)
        if "raw material" in joined or ("qty" in joined and ("unit" in joined or "uom" in joined)):
            header = [(c or "").strip().lower() for c in r]
            break
    if header is None:
        return []

    def col(*names):
        for i, h in enumerate(header):
            if any(n in h for n in names):
                return i
        return None

    ci_name = col("raw material", "material")
    ci_qty = col("qty")
    ci_unit = col("unit", "uom")
    ci_mw = col("m.wt", "m. wt", "mol. wt", "mw")
    ci_mol = col("mol.", "mol ")
    ci_ratio = col("mole ratio", "ratio")
    ci_rem = col("remark")
    ci_sr = col("s.no", "s. no", "sr")
    ci_dens = col("density", "dens", "sp. gr", "specific gravity")

    if ci_name is None:
        return []

    mats = []
    hdr_idx = tbl.index(next(r for r in tbl if [(c or "").strip().lower() for c in r] == header))
    for r in tbl[hdr_idx + 1:]:
        if not r or all((c or "").strip() == "" for c in r):
            continue
        name = (r[ci_name] or "").strip() if ci_name < len(r) else ""
        if not name or name.lower() in {"raw material", "material"}:
            continue
        qty = _to_float(r[ci_qty]) if ci_qty is not None and ci_qty < len(r) else None
        unit = (r[ci_unit] or "").strip().lower() if ci_unit is not None and ci_unit < len(r) else ""
        mw = _to_float(r[ci_mw]) if ci_mw is not None and ci_mw < len(r) else None
        if mw is None:                       # report left M.Wt blank (water/HCl/…)
            mw = _lookup_mw(name)
        dens = _to_float(r[ci_dens]) if ci_dens is not None and ci_dens < len(r) else None
        ratio = (r[ci_ratio] or "").strip() if ci_ratio is not None and ci_ratio < len(r) else ""
        rem = (r[ci_rem] or "").strip() if ci_rem is not None and ci_rem < len(r) else ""
        sr = int(_to_float(r[ci_sr]) or (len(mats) + 1)) if ci_sr is not None and ci_sr < len(r) else len(mats) + 1

        lab_g = qty if unit in _UNIT_SOLID else None
        lab_ml = qty if unit in _UNIT_LIQ else None
        # if unit missing, guess: has MW & 'g' vibes -> solid; else liquid
        if lab_g is None and lab_ml is None and qty is not None:
            lab_g = qty if mw else None
            lab_ml = qty if not mw else None

        remarks = (ratio + (" | " if ratio and rem else "") + rem).strip()
        mats.append(RawMaterial(sr_no=sr, name=name, lab_qty_g=lab_g,
                                lab_vol_ml=lab_ml, mw=mw, density=dens, remarks=remarks))
    return mats


# ---------------------------------------------------------------------------
def to_stage_calc(ps: ParsedStage, scale_up_ratio: float,
                  yield_override: Optional[float] = None,
                  project: str = "") -> StageCalc:
    """Convert a ParsedStage + manual ratio into a ready-to-compute StageCalc.

    Output basis, in order of preference:
      1. report's theoretical yield "X g for Y g of input"  -> mass ratio X/Y
         (most faithful to the report),
      2. reported yield % as a molar yield,
      3. default 0.8 molar yield.
    """
    lab_in = ps.lab_input_g or (ps.materials[0].lab_qty_g if ps.materials else 100.0) or 100.0
    in_mw = ps.input_mw or (ps.materials[0].mw if ps.materials else 1.0) or 1.0
    prod_mw = ps.product_mw or in_mw

    mass_ratio = None
    if ps.theo_out_g and ps.theo_in_g:
        mass_ratio = ps.theo_out_g / ps.theo_in_g

    yld = yield_override if yield_override is not None else (ps.yield_frac or 0.8)

    sc = StageCalc(
        name=ps.name, project=project,
        lab_input_g=lab_in, input_mw=in_mw, product_mw=prod_mw,
        scale_up_ratio=scale_up_ratio, yield_frac=yld,
        materials=ps.materials, steps=ps.steps,
    )
    sc.mass_ratio = mass_ratio    # engine uses this for output if set
    return sc
