"""CTGR3-style PFD writer: formula-linked worksheet with a mass-balance header,
a raw-material table, and a flowchart laid out as equipment blocks with operation
rows. Volumes and occupancy are live Excel formulas.

Layout mirrors the reference CTGR3 sheet:
  * raw-material table starting at MAT_START; plant quantities scale off the ratio
    cell so changing the batch/ratio recomputes everything,
  * flowchart operations reference the material rows (=B{row}, =F{row}/=E{row}),
  * each equipment block header shows Equipment ID, Capacity, min/max working
    volume and min/max % occupancy (working vol / capacity),
  * the running volume ledger carries forward (Min = previous Max, Max = Min + Σqty).
"""

from __future__ import annotations

import io
from typing import Optional

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from pfd_scaleup import StageCalc
from pfd_pipeline import is_decision

MAT_START = 16
RATIO_CELL = "I$12"
BATCH_CELL = "$C$9"

_GREEN = PatternFill("solid", fgColor="92D050")
_GREY = PatternFill("solid", fgColor="F2F2F2")
_BLUE = PatternFill("solid", fgColor="DDEBF7")
_HDR = PatternFill("solid", fgColor="D9E1F2")
_THIN = Side(style="thin", color="808080")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_C = Alignment("center", "center", wrap_text=True)
_L = Alignment("left", "center", wrap_text=True)
_F = "Calibri"


def _w(ws, coord, val, *, bold=False, fill=None, border=False, align=_C, size=11, color="000000"):
    c = ws[coord]
    c.value = val
    c.font = Font(name=_F, bold=bold, size=size, color=color)
    c.alignment = align
    if fill:
        c.fill = fill
    if border:
        c.border = _BORDER
    return c


def build(stages: list[StageCalc], ratios: Optional[list[float]] = None) -> bytes:
    wb = Workbook()
    wb.remove(wb.active)
    if ratios is None:
        ratios = [getattr(s, "scale_up_ratio", 1.0) for s in stages]
    for i, (stage, ratio) in enumerate(zip(stages, ratios), 1):
        ws = wb.create_sheet(title=(stage.name or f"Stage {i}")[:31])
        _write_stage(ws, stage, ratio)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _write_stage(ws, stage: StageCalc, ratio: float) -> None:
    widths = {"A": 22, "B": 30, "C": 12, "D": 34, "E": 13, "F": 12,
              "G": 20, "H": 13, "I": 12, "J": 11, "K": 11, "L": 13}
    for col, wd in widths.items():
        ws.column_dimensions[col].width = wd

    # title
    ws.merge_cells("A1:L1")
    t = ws["A1"]; t.value = "PROCESS FLOW DIAGRAM"
    t.font = Font(name=_F, bold=True, size=14, color="FFFFFF")
    t.fill = PatternFill("solid", fgColor="1F4E78"); t.alignment = _C
    ws.row_dimensions[1].height = 24
    _w(ws, "A2", "Project:", bold=True, align=_L); _w(ws, "C2", stage.project, align=_L)

    # ---- mass-balance block ----
    _w(ws, "A9", "Batch Size", bold=True, align=_L)
    _w(ws, "C9", round(stage.plant_batch_kg, 3)); _w(ws, "D9", "Kg")
    _w(ws, "F9", "Output", bold=True, align=_L)
    _w(ws, "I9", "=(C9*C12*I10)/C10"); _w(ws, "J9", "Kg")
    _w(ws, "A10", "Mol. Wt", bold=True, align=_L); _w(ws, "C10", stage.input_mw)
    _w(ws, "F10", "Mol. Wt", bold=True, align=_L); _w(ws, "I10", stage.product_mw)
    _w(ws, "A11", "Moles", bold=True, align=_L); _w(ws, "C11", "=C9/C10")
    _w(ws, "F11", "Moles", bold=True, align=_L); _w(ws, "I11", "=I9/I10")
    _w(ws, "A12", "Yield", bold=True, align=_L); _w(ws, "C12", round(stage.yield_frac, 3))
    _w(ws, "F12", "Scale-up ratio", bold=True, align=_L); _w(ws, "I12", "=C9/C16*1000")

    # ---- raw-material table ----
    ws.merge_cells("A14:A15"); _w(ws, "A14", "Sr. No.", bold=True, fill=_GREEN, border=True)
    ws.merge_cells("B14:B15"); _w(ws, "B14", "Raw material", bold=True, fill=_GREEN, border=True)
    ws.merge_cells("C14:D14"); _w(ws, "C14", "Lab Batch", bold=True, fill=_GREEN, border=True)
    ws.merge_cells("E14:F14"); _w(ws, "E14", "Plant Batch", bold=True, fill=_GREEN, border=True)
    for coord, txt in [("G14", "Mol. Wt"), ("H14", "Moles"), ("I14", "W/w"),
                       ("J14", "V/W"), ("K14", "Density"), ("L14", "Remarks")]:
        ws.merge_cells(f"{coord[0]}14:{coord[0]}15")
        _w(ws, coord, txt, bold=True, fill=_GREEN, border=True)
    _w(ws, "C15", "Qty (gm)", bold=True, fill=_GREEN, border=True)
    _w(ws, "D15", "Vol (ml)", bold=True, fill=_GREEN, border=True)
    _w(ws, "E15", "Qty (Kg)", bold=True, fill=_GREEN, border=True)
    _w(ws, "F15", "Vol (L)", bold=True, fill=_GREEN, border=True)

    mat_row: dict[str, int] = {}
    r = MAT_START
    for m in stage.materials:
        mat_row[m.name] = r
        _w(ws, f"A{r}", m.sr_no, border=True)
        _w(ws, f"B{r}", m.name, border=True, align=_L)
        _w(ws, f"C{r}", m.lab_qty_g, border=True)
        _w(ws, f"D{r}", m.lab_vol_ml, border=True)
        _w(ws, f"E{r}", f"=C{r}*{RATIO_CELL}/1000" if m.lab_qty_g else None, border=True)
        _w(ws, f"F{r}", f"=D{r}*{RATIO_CELL}/1000" if m.lab_vol_ml else None, border=True)
        _w(ws, f"G{r}", m.mw, border=True)
        _w(ws, f"H{r}", f"=E{r}/G{r}" if (m.lab_qty_g and m.mw) else None, border=True)
        _w(ws, f"I{r}", f"=E{r}/{BATCH_CELL}" if m.lab_qty_g else None, border=True)
        _w(ws, f"J{r}", f"=F{r}/{BATCH_CELL}" if m.lab_vol_ml else None, border=True)
        _w(ws, f"K{r}", m.density, border=True)
        _w(ws, f"L{r}", m.remarks, border=True, align=_L)
        r += 1

    _link_step_materials(stage)
    _write_flowchart(ws, stage, mat_row, start_row=r + 2)


def _link_step_materials(stage: StageCalc) -> None:
    import pandas as pd
    from pfd_pipeline import load_material_sheet, assign_materials
    for s in stage.steps:
        s.materials, s.quantities = [], []
    rows = [[m.sr_no, m.name, None, m.plant_kg, m.plant_l] for m in stage.materials]
    if rows:
        mats = load_material_sheet(pd.DataFrame(rows), name_col=1, kg_col=3, l_col=4)
        assign_materials(stage.steps, mats)


def _write_flowchart(ws, stage: StageCalc, mat_row: dict, start_row: int) -> None:
    row = start_row
    # equipment block header
    hdr = ["Equipment grouping", "Equipment ID", "Capacity", "UOM",
           "Min working vol (L)", "Min % occupancy", "Max working vol (L)",
           "Max % occupancy", "", "Min Vol L", "Max Vol L"]
    for c, txt in enumerate(hdr, 1):
        if txt:
            _w(ws, f"{chr(64+c)}{row}", txt, bold=True, fill=_HDR, border=True)
    row += 1
    block_hdr = row
    cap = stage.reactor_capacity or ""
    _w(ws, f"A{row}", "R-1", bold=True, border=True)
    _w(ws, f"B{row}", stage.reactor_id or "", bold=True, border=True)
    _w(ws, f"C{row}", cap, border=True)
    _w(ws, f"D{row}", "L", border=True)
    row += 1

    prev_max = None
    first_min_cell = None
    last_max_cell = None

    for idx, s in enumerate(stage.steps):
        op_row = row
        ws.row_dimensions[op_row].height = 30
        dc = ws.cell(row=op_row, column=4, value=s.full_text)  # D
        dc.alignment = _L
        dc.fill = _BLUE if is_decision(s) else _GREY
        dc.font = Font(name=_F, bold=is_decision(s), size=11)
        dc.border = _BORDER

        qty_cells = []
        sub = op_row
        for mname in s.materials:
            mr = mat_row.get(mname)
            if mr is None:
                continue
            m = next((x for x in stage.materials if x.name == mname), None)
            _w(ws, f"A{sub}", f"=B{mr}", border=True, align=_L)
            if m and m.lab_vol_ml:
                _w(ws, f"B{sub}", f"=F{mr}", border=True)
                _w(ws, f"C{sub}", "L", border=True)
                qty_cells.append(f"B{sub}")
            else:
                _w(ws, f"B{sub}", f"=E{mr}", border=True)
                _w(ws, f"C{sub}", "Kg", border=True)
                if m and m.density:                       # solution volume sub-row
                    sub += 1
                    _w(ws, f"B{sub}", f"=B{sub-1}/K{mr}", border=True)
                    _w(ws, f"C{sub}", "L", border=True)
                    qty_cells.append(f"B{sub}")
                else:
                    qty_cells.append(f"B{sub}")
            sub += 1

        mn = ws.cell(row=op_row, column=10); mn.alignment = _C; mn.border = _BORDER  # J
        mx = ws.cell(row=op_row, column=11); mx.alignment = _C; mx.border = _BORDER  # K
        mn.value = 0 if prev_max is None else f"={prev_max}"
        mx.value = (f"=J{op_row}+" + "+".join(qty_cells)) if qty_cells else f"=J{op_row}"
        prev_max = f"K{op_row}"
        if first_min_cell is None:
            first_min_cell = f"J{op_row}"
        last_max_cell = f"K{op_row}"

        row = max(sub, op_row) + 2

    # equipment occupancy formulas on the block header
    if first_min_cell and last_max_cell:
        capref = f"C{block_hdr}"
        _w(ws, f"E{block_hdr}", f"={first_min_cell}", border=True)
        _w(ws, f"F{block_hdr}", f'=IF({capref}="","",E{block_hdr}/{capref})', border=True)
        _w(ws, f"H{block_hdr}", f"={last_max_cell}", border=True)
        _w(ws, f"I{block_hdr}", f'=IF({capref}="","",H{block_hdr}/{capref})', border=True)
