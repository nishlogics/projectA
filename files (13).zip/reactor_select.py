"""Reactor selection from CTO3-style block equipment sheets.

Each block sheet (A-E, B-E, ... I-E) lists reactors with two working-volume
limits, under different labels that mean the same thing:

    Thermowell touching  ==  MSV (minimum sensing volume)   -> temperature sensing
    Stirrer touching     ==  TSV                            -> agitation

each split into WITHOUT stirring ("stagnant") and WITH stirring.

Selection rule (per process requirement):
  * consider GLR (glass-lined) reactors only,
  * a reactor's minimum working volume is its thermowell / MSV WITHOUT stirring,
  * the first working volume after charging the first material (Water Lot-1)
    must be >= that minimum, so temperature can be sensed from the first charge,
  * the peak working volume across the process must fit under capacity * fill.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

import pandas as pd
from openpyxl import load_workbook


@dataclass
class Reactor:
    eq_id: str
    block: str
    capacity_l: float
    agitator: str
    thermowell_stir: Optional[float]      # sensing, with stirring
    thermowell_nostir: Optional[float]    # sensing, without stirring  (the min limit)
    stirrer_stir: Optional[float]
    stirrer_nostir: Optional[float]

    @property
    def moc(self) -> str:
        m = re.match(r"[A-Za-z]*?(GLR|SSR|HLR|SS|GL|HL)", self.eq_id.upper())
        return m.group(1) if m else ""

    @property
    def is_glr(self) -> bool:
        return "GLR" in self.eq_id.upper() or self.moc in ("GLR", "GL")

    @property
    def min_volume_l(self) -> Optional[float]:
        """Minimum working volume = thermowell / MSV without stirring."""
        return self.thermowell_nostir


def _num(v):
    if v is None:
        return None
    s = re.sub(r"[^\d.]", "", str(v))
    try:
        return float(s) if s else None
    except ValueError:
        return None


def load_reactors(path: str, block: str = "I-E") -> list[Reactor]:
    """Read reactors from a single block sheet (default I-E) of a CTO3 equipment
    workbook. Pass block=None to read every sheet."""
    wb = load_workbook(path, data_only=True)

    if block is None:
        sheets = wb.sheetnames
    else:
        # match the requested block sheet, tolerant of stray spaces / case
        target = block.strip().lower()
        sheets = [s for s in wb.sheetnames if s.strip().lower() == target]
        if not sheets:
            sheets = [s for s in wb.sheetnames if target in s.strip().lower()]
        if not sheets:
            raise ValueError(f"Sheet '{block}' not found. Available: {wb.sheetnames}")

    reactors: list[Reactor] = []
    for sheet in sheets:
        ws = wb[sheet]
        blk = sheet.strip()
        rows = [[ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
                for r in range(1, ws.max_row + 1)]
        cols = _detect_columns(rows)
        if not cols:
            continue
        for r in rows[cols["data_start"]:]:
            eq = r[cols["eq"]] if cols["eq"] < len(r) else None
            if not eq or not str(eq).strip():
                continue
            eq = str(eq).strip()
            if not re.search(r"[A-Za-z].*\d", eq):
                continue
            cap = _num(r[cols["cap"]]) if cols["cap"] is not None and cols["cap"] < len(r) else None
            if cap is None:
                continue

            def val(key):
                i = cols.get(key)
                return _num(r[i]) if i is not None and i < len(r) else None

            reactors.append(Reactor(
                eq_id=eq, block=blk, capacity_l=cap,
                agitator=str(r[cols["agit"]]).strip() if cols.get("agit") is not None
                          and cols["agit"] < len(r) and r[cols["agit"]] else "",
                thermowell_stir=val("tw_stir"),
                thermowell_nostir=val("tw_nostir"),
                stirrer_stir=val("st_stir"),
                stirrer_nostir=val("st_nostir"),
            ))
    return reactors


def _detect_columns(rows: list[list]) -> Optional[dict]:
    """Locate the reactor-table columns in a block sheet, handling both the
    THERMOWELL/STIRRER layout and the MSV/TSV layout."""
    for i, row in enumerate(rows[:12]):
        cells = [str(c).strip().lower() if c is not None else "" for c in row]
        joined = " ".join(cells)
        has_cap = any("capacity" in c for c in cells)
        has_therm = "thermowell" in joined or "msv" in joined
        has_stir = "stirrer" in joined or "tsv" in joined
        has_reactor = any(("reactor" in c or "equipment" in c) for c in cells)
        if has_cap and (has_therm or has_stir or has_reactor):
            return _build_colmap(rows, i, cells)
    return None


def _build_colmap(rows, header_i, cells) -> dict:
    def find(*keys):
        for idx, c in enumerate(cells):
            if any(k in c for k in keys):
                return idx
        return None

    eq = find("equipment", "reactor")
    cap = find("capacity")
    agit = find("agitator", "type of agit")
    therm = find("thermowell", "msv")
    stirr = find("stirrer", "tsv")

    # sub-header row (WITH/WITHOUT or Stagnant/Stirring) is usually the next row
    sub = [str(c).strip().lower() if c is not None else "" for c in rows[header_i + 1]] \
        if header_i + 1 < len(rows) else []

    def pair(start_idx):
        """Given the left column of a 2-wide (with/without) group, return
        (without_stir_idx, with_stir_idx) by reading the sub-header."""
        if start_idx is None:
            return None, None
        a, b = start_idx, start_idx + 1
        sa = sub[a] if a < len(sub) else ""
        sb = sub[b] if b < len(sub) else ""
        # 'without' / 'stagnant' is the no-stir column
        if "without" in sa or "stagn" in sa:
            return a, b
        if "without" in sb or "stagn" in sb:
            return b, a
        # default: first = without, second = with
        return a, b

    tw_no, tw_yes = pair(therm)
    st_no, st_yes = pair(stirr)

    # data starts after header + subheader
    data_start = header_i + 1
    if any(("with" in s or "without" in s or "stagn" in s or "stirring" in s) for s in sub):
        data_start = header_i + 2

    return {"eq": eq, "cap": cap, "agit": agit,
            "tw_nostir": tw_no, "tw_stir": tw_yes,
            "st_nostir": st_no, "st_stir": st_yes,
            "data_start": data_start}


def select_reactors(reactors: list[Reactor], first_charge_vol_l: float,
                    peak_vol_l: float, fill_factor: float = 0.8,
                    glr_only: bool = True) -> list[Reactor]:
    """Apply the selection rule and return qualifying reactors, best fit first.

    first_charge_vol_l : working volume right after the first charge (Water Lot-1)
    peak_vol_l         : maximum working volume reached during the process
    fill_factor        : peak must be <= capacity * fill_factor
    """
    out = []
    for rx in reactors:
        if glr_only and not rx.is_glr:
            continue
        if rx.min_volume_l is not None and first_charge_vol_l < rx.min_volume_l:
            continue                                  # can't sense temp at first charge
        if peak_vol_l > rx.capacity_l * fill_factor:
            continue                                  # overfills
        out.append(rx)

    # best fit: smallest capacity that still fits (least wasted volume)
    out.sort(key=lambda r: r.capacity_l)
    return out
