"""Load equipment master files (any of the plant/lab formats) and fit reactors
to a stage based on its working volume."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

import pandas as pd


@dataclass
class Equipment:
    eq_id: str
    capacity_l: Optional[float] = None
    moc: str = ""
    agitator: str = ""
    rpm: Optional[float] = None
    min_stir_l: Optional[float] = None
    min_sense_l: Optional[float] = None
    block: str = ""


# column name hints (lower-case substrings) -> field
_HINTS = {
    "eq_id": ["eq.i.d", "eq id", "equipment i", "equipment name", "reactor",
              "eq.id", "vessel id", "stage name"],
    "capacity_l": ["capacity"],
    "moc": ["moc"],
    "agitator": ["agitator", "impeller"],
    "rpm": ["rpm"],
    "min_stir_l": ["min stirr", "min stirring", "stirring", "msv"],
    "min_sense_l": ["min sensing", "sensing", "min sens"],
}


def _num(v) -> Optional[float]:
    if v is None:
        return None
    s = re.sub(r"[^\d.]", "", str(v))
    try:
        return float(s) if s else None
    except ValueError:
        return None


def _find_header_row(rows: list[list]) -> Optional[int]:
    """The header row is the first row mentioning capacity plus an id/name column."""
    for i, r in enumerate(rows[:15]):
        joined = " ".join(str(c or "").lower() for c in r)
        if "capacity" in joined and any(
                k in joined for k in ["eq", "reactor", "vessel", "stage name", "equipment"]):
            return i
    return None


def _map_columns(header: list[str]) -> dict:
    col = {}
    low = [str(h or "").strip().lower() for h in header]
    for field, hints in _HINTS.items():
        for i, h in enumerate(low):
            if any(hint in h for hint in hints):
                col.setdefault(field, i)
                break
    return col


def _rows_from_sheet(df: pd.DataFrame) -> list[list]:
    return df.values.tolist()


def load_equipment(file, sheet_name: Optional[str] = None) -> list[Equipment]:
    """Read an equipment file (.xlsx or .xls). Scans sheets for an equipment table
    and returns a flat list of Equipment across all matching sheets/blocks."""
    xl = pd.ExcelFile(file)
    sheets = [sheet_name] if sheet_name else xl.sheet_names

    out: list[Equipment] = []
    for sn in sheets:
        try:
            df = xl.parse(sn, header=None, dtype=object)
        except Exception:
            continue
        rows = _rows_from_sheet(df)
        hr = _find_header_row(rows)
        if hr is None:
            continue
        col = _map_columns(rows[hr])
        if "eq_id" not in col or "capacity_l" not in col:
            continue

        block = str(sn).strip()
        for r in rows[hr + 1:]:
            if not r or col["eq_id"] >= len(r):
                continue
            eid = r[col["eq_id"]]
            if eid is None or str(eid).strip() == "":
                continue
            cap = _num(r[col["capacity_l"]]) if col["capacity_l"] < len(r) else None
            if cap is None:
                continue
            # capacity in KL -> convert to L only when the header explicitly says KL
            hdr_txt = str(rows[hr][col["capacity_l"]]).lower()
            if "kl" in hdr_txt or "(kl" in hdr_txt:
                cap = cap * 1000

            def g(f):
                i = col.get(f)
                return r[i] if (i is not None and i < len(r)) else None

            out.append(Equipment(
                eq_id=str(eid).strip(),
                capacity_l=cap,
                moc=str(g("moc") or "").strip(),
                agitator=str(g("agitator") or "").strip(),
                rpm=_num(g("rpm")),
                min_stir_l=_num(g("min_stir_l")),
                min_sense_l=_num(g("min_sense_l")),
                block=block,
            ))
    return out


_REACTOR_HINT = re.compile(r"(glr|ssr|hlr|har|reactor|rcvd|glass|glass lined)", re.I)
_NONREACTOR_HINT = re.compile(r"(filter|dryer|nutsche|centrifuge|nf/|pnf|fbd|rvd|ss/|spf|anf|receiver|hold)", re.I)


_REACTOR_PREFIX = re.compile(r"^\s*(a?glr|a?ssr|a?hlr|a?har|reactor|r-?\d)", re.I)


def is_reactor(e: "Equipment") -> bool:
    if _REACTOR_PREFIX.match(e.eq_id):
        return True
    ag = str(e.agitator).strip().lower()
    return ag not in ("", "nan", "-", "none") and not _NONREACTOR_HINT.search(e.eq_id)


_is_reactor = is_reactor  # backward-compat alias


def fit_reactor(equipment: list[Equipment], working_vol_l: float,
                occupancy: float = 0.8, reactors_only: bool = True) -> list[Equipment]:
    """Return vessels that can hold `working_vol_l`, smallest suitable first.

    A vessel fits when:
      working_vol <= capacity * occupancy   (headroom), and
      working_vol >= min stirring / sensing volume (if known).
    By default only true reactors are considered (filters/dryers excluded).
    """
    fits = []
    for e in equipment:
        if not e.capacity_l:
            continue
        if reactors_only and not _is_reactor(e):
            continue
        if working_vol_l > e.capacity_l * occupancy:
            continue
        floor = max(x for x in [e.min_stir_l, e.min_sense_l, 0] if x is not None)
        if floor and working_vol_l < floor:
            continue
        fits.append(e)
    fits.sort(key=lambda e: e.capacity_l)
    return fits


def best_reactor(equipment: list[Equipment], working_vol_l: float,
                 occupancy: float = 0.8) -> Optional[Equipment]:
    fits = fit_reactor(equipment, working_vol_l, occupancy)
    return fits[0] if fits else None
